# Space Debris Detection Dataset

## Structure
```
debris_detection/
├── images/
│   ├── train/   ← Place 40,000+ training images here
│   └── val/     ← Place 10,000+ validation images here
├── labels/
│   ├── train/   ← YOLO format .txt label files (one per image)
│   └── val/
└── data.yaml    ← Training configuration
```

## Label Format (YOLO)
Each `.txt` file corresponds to an image with the same filename.
Each line: `class_id cx cy w h` (all normalized 0-1)

```
0 0.512 0.341 0.045 0.038    # debris
0 0.721 0.189 0.023 0.019    # debris
1 0.102 0.876 0.112 0.094    # satellite
2 0.654 0.512 0.087 0.065    # rocket_body
```

## Class IDs
- 0: debris
- 1: satellite
- 2: rocket_body

## Data Sources
- ESA Space Debris Office: https://www.esa.int/Safety_Security/Space_Debris
- NASA Earth Data: https://earthdata.nasa.gov
- Sentinel Hub: https://www.sentinel-hub.com
- Planet Labs Open Data: https://www.planet.com/open

## Annotation Tools
- Roboflow (recommended): https://roboflow.com
- CVAT: https://cvat.ai
- LabelImg: https://github.com/heartexlabs/labelImg
