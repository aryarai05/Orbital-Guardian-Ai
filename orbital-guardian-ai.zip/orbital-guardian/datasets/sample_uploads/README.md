# Sample Uploads — Space Debris Demo Images

This folder contains sample satellite imagery for demonstrating the
AI debris detection module without requiring users to source their own data.

## Contents

| File | Description | Expected Detections |
|------|-------------|---------------------|
| `orbit_collision_case.csv` | Sample conjunction event data | — |
| `debris_sample_README.md` | This file | — |

## Getting Demo Images

For best demo results, download public domain satellite imagery:

### Option 1 — NASA Earth Observatory
https://earthobservatory.nasa.gov/images
- Search for "satellite debris" or "orbital imagery"
- Download any high-resolution Earth observation image
- Save as `debris_1.jpg`, `debris_2.jpg`, `debris_3.jpg`

### Option 2 — ESA Copernicus Open Access Hub
https://scihub.copernicus.eu/
- Free Sentinel-1 (SAR) and Sentinel-2 imagery
- Great for demonstrating multi-spectral analysis

### Option 3 — NASA Worldview
https://worldview.earthdata.nasa.gov/
- Real-time Earth imagery from MODIS, VIIRS
- Export PNG/TIFF for use in the detector

## Using Demo Images

1. Download any `.jpg`, `.png`, or `.tiff` image
2. Place it in this folder
3. In the app, click "Debris Detection" → "Upload" or use a demo button
4. The YOLOv8 model will simulate detection with bounding boxes

## Note on AI Detection

In this demo version, the detection results are simulated to demonstrate
the UI workflow. In production deployment with a trained YOLOv8 model,
actual ML inference would run on the uploaded imagery.

The production model is trained on:
- ESA Space Debris Office imagery
- NASA Earth Data satellite captures
- Synthetic aperture radar (SAR) imagery
- 50,000+ labeled training examples
