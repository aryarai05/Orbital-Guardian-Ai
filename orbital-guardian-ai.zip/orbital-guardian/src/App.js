import React, { useState, useEffect } from 'react';
import Landing from './components/landing/Landing';
import Dashboard from './components/dashboard/Dashboard';
import SolarSystem from './components/solar-system/SolarSystem';
import DebrisDetection from './components/debris/DebrisDetection';
import CollisionPrediction from './components/collision/CollisionPrediction';
import OrbitSimulation from './components/collision/OrbitSimulation';
import EducationCenter from './components/education/EducationCenter';
import AstraAssistant from './components/assistant/AstraAssistant';
import Gamification from './components/gamification/Gamification';
import WhyItMatters from './components/education/WhyItMatters';
import NavBar from './components/landing/NavBar';
import StarField from './components/landing/StarField';
import './styles/global.css';

export default function App() {
  const [currentView, setCurrentView] = useState('landing');
  const [missionLaunched, setMissionLaunched] = useState(false);
  const [achievements, setAchievements] = useState([]);
  const [astraOpen, setAstraOpen] = useState(false);

  const unlockAchievement = (id) => {
    setAchievements(prev => {
      if (!prev.includes(id)) {
        return [...prev, id];
      }
      return prev;
    });
  };

  const navigate = (view) => {
    setCurrentView(view);
    if (view === 'solar-system') unlockAchievement('space-explorer');
    if (view === 'debris') unlockAchievement('debris-hunter');
    if (view === 'collision') unlockAchievement('ai-commander');
  };

  return (
    <div className="app-root">
      <StarField />
      {!missionLaunched ? (
        <Landing onLaunch={() => { setMissionLaunched(true); setCurrentView('dashboard'); }} />
      ) : (
        <>
          <NavBar currentView={currentView} onNavigate={navigate} />
          <main className="main-content">
            {currentView === 'dashboard' && <Dashboard onNavigate={navigate} />}
            {currentView === 'solar-system' && <SolarSystem unlockAchievement={unlockAchievement} />}
            {currentView === 'debris' && <DebrisDetection />}
            {currentView === 'collision' && <CollisionPrediction />}
            {currentView === 'orbit' && <OrbitSimulation />}
            {currentView === 'education' && <EducationCenter />}
            {currentView === 'why-matters' && <WhyItMatters />}
            {currentView === 'achievements' && <Gamification achievements={achievements} />}
          </main>
          <AstraAssistant isOpen={astraOpen} onToggle={() => setAstraOpen(!astraOpen)} onNavigate={navigate} />
          {achievements.length > 0 && <AchievementToast achievement={achievements[achievements.length - 1]} />}
        </>
      )}
    </div>
  );
}

function AchievementToast({ achievement }) {
  const [visible, setVisible] = useState(true);
  const labels = { 'space-explorer': '🚀 Space Explorer', 'debris-hunter': '🎯 Debris Hunter', 'ai-commander': '🤖 AI Commander', 'planet-master': '🪐 Planet Master' };

  useEffect(() => {
    const t = setTimeout(() => setVisible(false), 4000);
    return () => clearTimeout(t);
  }, [achievement]);

  if (!visible) return null;
  return (
    <div className="achievement-toast">
      <div className="achievement-toast-inner">
        <span className="achievement-badge-icon">🏆</span>
        <div>
          <div className="achievement-toast-title">Achievement Unlocked!</div>
          <div className="achievement-toast-name">{labels[achievement] || achievement}</div>
        </div>
      </div>
    </div>
  );
}
