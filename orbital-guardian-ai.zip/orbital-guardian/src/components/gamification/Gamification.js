import React from 'react';

const ALL_ACHIEVEMENTS = [
  {
    id: 'space-explorer',
    title: 'Space Explorer',
    icon: '🚀',
    description: 'Visited the Solar System module and explored the planets.',
    how: 'Navigate to the Solar System module',
    xp: 100,
    rarity: 'Common',
    rarityColor: 'var(--accent-green)',
  },
  {
    id: 'planet-master',
    title: 'Planet Master',
    icon: '🪐',
    description: 'Clicked on a planet to view detailed information and voice narration.',
    how: 'Click any planet in the Solar System view',
    xp: 250,
    rarity: 'Uncommon',
    rarityColor: 'var(--accent-blue)',
  },
  {
    id: 'debris-hunter',
    title: 'Debris Hunter',
    icon: '🎯',
    description: 'Used the AI-powered debris detection module to scan satellite imagery.',
    how: 'Visit the Debris Detection module',
    xp: 350,
    rarity: 'Rare',
    rarityColor: 'var(--accent-purple)',
  },
  {
    id: 'ai-commander',
    title: 'AI Commander',
    icon: '🤖',
    description: 'Ran a collision prediction analysis using the ML model.',
    how: 'Visit the Collision AI module',
    xp: 500,
    rarity: 'Epic',
    rarityColor: 'var(--accent-orange)',
  },
  {
    id: 'orbit-watcher',
    title: 'Orbit Watcher',
    icon: '🛸',
    description: 'Observed satellites and debris in the real-time orbit simulation.',
    how: 'Visit the Orbit Simulation module',
    xp: 200,
    rarity: 'Common',
    rarityColor: 'var(--accent-green)',
  },
  {
    id: 'knowledge-seeker',
    title: 'Knowledge Seeker',
    icon: '📚',
    description: 'Studied space topics in the Space Academy education center.',
    how: 'Visit the Space Academy module',
    xp: 150,
    rarity: 'Common',
    rarityColor: 'var(--accent-green)',
  },
  {
    id: 'guardian',
    title: 'Guardian of Orbit',
    icon: '🛡️',
    description: 'Unlocked all core mission modules — a true Orbital Guardian.',
    how: 'Unlock all other achievements',
    xp: 1000,
    rarity: 'Legendary',
    rarityColor: 'var(--accent-yellow)',
  },
  {
    id: 'voice-activated',
    title: 'Voice Activated',
    icon: '🔊',
    description: 'Used voice narration to hear about the planets or space topics.',
    how: 'Click any voice narration button',
    xp: 75,
    rarity: 'Common',
    rarityColor: 'var(--accent-green)',
  },
];

export default function Gamification({ achievements }) {
  const totalXP = achievements.reduce((sum, id) => {
    const ach = ALL_ACHIEVEMENTS.find(a => a.id === id);
    return sum + (ach?.xp || 0);
  }, 0);

  const level = Math.floor(totalXP / 500) + 1;
  const xpToNextLevel = (level * 500) - totalXP;
  const progressPct = ((totalXP % 500) / 500) * 100;

  const allUnlocked = ALL_ACHIEVEMENTS.every(a => achievements.includes(a.id));
  if (allUnlocked && !achievements.includes('guardian')) {
    achievements = [...achievements, 'guardian'];
  }

  return (
    <div style={{ padding: '24px', maxWidth: '1100px', margin: '0 auto' }}>
      <div style={{ marginBottom: '28px' }}>
        <div style={{ fontSize: '36px', marginBottom: '8px' }}>🏆</div>
        <h1 className="section-title">ACHIEVEMENTS</h1>
        <p className="section-sub">Track your progress through the Orbital Guardian platform</p>
      </div>

      {/* Player card */}
      <div className="glass-card" style={{ padding: '24px', marginBottom: '28px', display: 'flex', gap: '24px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ width: '80px', height: '80px', borderRadius: '50%', background: 'linear-gradient(135deg, #0040a0, #0080ff, #00c0ff)', border: '3px solid var(--accent-cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '36px', boxShadow: 'var(--glow-cyan)', flexShrink: 0 }}>
          👨‍🚀
        </div>
        <div style={{ flex: 1, minWidth: '200px' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'white', marginBottom: '4px' }}>COMMANDER</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px', flexWrap: 'wrap' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)' }}>Level {level}</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--accent-yellow)' }}>{totalXP} XP</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-dim)' }}>{xpToNextLevel} XP to next level</span>
          </div>
          <div className="progress-bar-bg" style={{ height: '8px' }}>
            <div className="progress-bar-fill" style={{ width: `${progressPct}%`, background: 'linear-gradient(90deg, var(--accent-blue), var(--accent-cyan))', boxShadow: '0 0 8px rgba(0,245,255,0.4)' }} />
          </div>
        </div>
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          {[
            { v: achievements.length, l: 'Unlocked' },
            { v: ALL_ACHIEVEMENTS.length - achievements.length, l: 'Remaining' },
            { v: totalXP, l: 'Total XP' },
          ].map(s => (
            <div key={s.l} style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: 'var(--accent-cyan)', fontWeight: 700 }}>{s.v}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px' }}>{s.l.toUpperCase()}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '16px' }}>
        {ALL_ACHIEVEMENTS.map(ach => {
          const unlocked = achievements.includes(ach.id);
          return (
            <div key={ach.id} className="glass-card" style={{ padding: '20px', opacity: unlocked ? 1 : 0.5, filter: unlocked ? 'none' : 'grayscale(0.7)', transition: 'all 0.3s', borderColor: unlocked ? ach.rarityColor.replace('var(--accent-', 'rgba(').replace(')', ', 0.4)').replace('cyan', '0,245,255').replace('blue', '0,128,255').replace('purple', '128,0,255').replace('orange', '255,102,0').replace('yellow', '255,204,0').replace('green', '0,255,136') : 'rgba(0,60,120,0.3)' }}>
              <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
                <div style={{ width: '52px', height: '52px', borderRadius: '12px', background: unlocked ? 'rgba(0,20,60,0.8)' : 'rgba(0,10,30,0.6)', border: `2px solid ${unlocked ? ach.rarityColor : 'rgba(0,60,120,0.3)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px', flexShrink: 0, boxShadow: unlocked ? `0 0 15px ${ach.rarityColor}33` : 'none' }}>
                  {unlocked ? ach.icon : '🔒'}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px', flexWrap: 'wrap', gap: '4px' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: unlocked ? 'white' : 'var(--text-dim)', letterSpacing: '1px' }}>{ach.title}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: ach.rarityColor, background: `${ach.rarityColor}15`, padding: '2px 6px', borderRadius: '4px', border: `1px solid ${ach.rarityColor}40` }}>{ach.rarity.toUpperCase()}</span>
                  </div>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: unlocked ? 'var(--text-secondary)' : 'var(--text-dim)', lineHeight: 1.4, marginBottom: '8px' }}>
                    {unlocked ? ach.description : ach.how}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: unlocked ? 'var(--accent-yellow)' : 'var(--text-dim)' }}>+{ach.xp} XP</span>
                    {unlocked && <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-green)' }}>✓ UNLOCKED</span>}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Progress summary */}
      <div className="glass-card" style={{ padding: '20px', marginTop: '24px', textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '12px' }}>
          ORBITAL GUARDIAN RANK
        </div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '28px', color: 'white', marginBottom: '8px' }}>
          {totalXP === 0 ? '🌍 Earthbound' : totalXP < 500 ? '🛸 Orbital Cadet' : totalXP < 1200 ? '🚀 Space Pioneer' : totalXP < 2000 ? '🌌 Star Commander' : '⭐ Orbital Guardian'}
        </div>
        <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', maxWidth: '500px', margin: '0 auto', lineHeight: 1.6 }}>
          {totalXP === 0
            ? 'Begin your mission by exploring the platform modules. Every interaction earns XP!'
            : totalXP < 1200
            ? 'You\'re making progress, Commander. Keep exploring modules to unlock more achievements and advance your rank.'
            : 'Outstanding work, Commander. You are a true guardian of Earth\'s orbital environment.'}
        </p>
      </div>
    </div>
  );
}
