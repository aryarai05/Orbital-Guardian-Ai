import React, { useState, useRef, useEffect } from 'react';
import { knowledgeBase } from '../../data/spaceData';
import { planetsData } from '../../data/planets';

const ASTRA_RESPONSES = {
  greeting: "Hello Commander. I'm Astra, your AI space assistant. I can answer questions about planets, space debris, satellites, and more. Try asking me about Mars, the ISS, or Kessler Syndrome.",
  help: "I can help you with: planet information, space debris facts, collision risks, satellite data, black holes, space missions, and orbital mechanics. Just ask!",
  default: "Fascinating question, Commander. While my data banks are processing this, I recommend checking the Space Academy module for more detailed information on this topic.",
};

const QUICK_COMMANDS = [
  { label: 'Tell me about Mars', cmd: 'tell me about mars' },
  { label: 'What is Kessler Syndrome?', cmd: 'kessler syndrome' },
  { label: 'Show dangerous debris', cmd: 'dangerous debris' },
  { label: 'Explain black holes', cmd: 'black holes' },
  { label: 'Compare Earth and Venus', cmd: 'compare earth and venus' },
  { label: 'ISS information', cmd: 'iss' },
];

export default function AstraAssistant({ isOpen, onToggle, onNavigate }) {
  const [messages, setMessages] = useState([
    { id: 1, from: 'astra', text: "Commander, ASTRA online. I'm monitoring Earth's orbital environment and ready to assist. What would you like to know?", time: new Date().toLocaleTimeString() }
  ]);
  const [input, setInput] = useState('');
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.88; u.pitch = 0.65; u.volume = 0.85;
      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => v.name.includes('Google') && v.lang === 'en-US') || voices.find(v => v.lang === 'en-US');
      if (preferred) u.voice = preferred;
      u.onstart = () => setSpeaking(true);
      u.onend = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    }
  };

  const getResponse = (query) => {
    const q = query.toLowerCase().trim();

    // Navigate commands
    if (q.includes('solar system') || q.includes('show planets')) {
      onNavigate('solar-system');
      return "Launching the Solar System module, Commander. You can click any planet for detailed information and voice narration.";
    }
    if (q.includes('debris detection') || q.includes('scan for debris') || q.includes('dangerous debris') || q.includes('show dangerous')) {
      onNavigate('debris');
      return "Opening the Space Debris Detection module. Upload a satellite image to run our YOLOv8 AI detection model, or use one of our demo samples.";
    }
    if (q.includes('collision') || q.includes('start collision') || q.includes('conjunction')) {
      onNavigate('collision');
      return "Loading the Collision Prediction AI. Adjust the trajectory parameters and run our machine learning model to calculate collision probabilities.";
    }
    if (q.includes('orbit') || q.includes('simulation')) {
      onNavigate('orbit');
      return "Launching the real-time Orbit Simulation. You can observe all tracked satellites and debris objects in live animated orbits around Earth.";
    }
    if (q.includes('education') || q.includes('space academy') || q.includes('learn')) {
      onNavigate('education');
      return "Opening Space Academy. You'll find interactive lessons on black holes, nebulae, exoplanets, space missions, and rocket science.";
    }
    if (q.includes('dashboard') || q.includes('mission control')) {
      onNavigate('dashboard');
      return "Returning to Mission Control. The dashboard shows real-time statistics, active threats, and live alerts.";
    }

    // Planet queries
    const planet = planetsData.find(p => q.includes(p.name.toLowerCase()) || q.includes(p.id));
    if (planet) return planet.voiceText;

    // Compare planets
    if (q.includes('compare')) {
      const planets = planetsData.filter(p => q.includes(p.name.toLowerCase()) || q.includes(p.id));
      if (planets.length >= 2) {
        return `Comparing ${planets[0].name} and ${planets[1].name}. ${planets[0].name} has a diameter of ${planets[0].diameter.toLocaleString()} km and gravity of ${planets[0].gravity} m/s², while ${planets[1].name} has a diameter of ${planets[1].diameter.toLocaleString()} km and gravity of ${planets[1].gravity} m/s². Their temperatures differ significantly: ${planets[0].name} averages ${planets[0].temperature}°C, while ${planets[1].name} averages ${planets[1].temperature}°C.`;
      }
    }

    // Knowledge base lookups
    if (q.includes('kessler') || q.includes('debris cascade')) {
      return "Kessler Syndrome is a catastrophic scenario proposed by NASA scientist Donald Kessler in 1978. If orbital debris reaches a critical density, collisions generate more debris, triggering more collisions in an unstoppable chain reaction. This could render low Earth orbit permanently unusable — no GPS, communications, or weather satellites. We currently track over 27,000 debris objects, and millions of smaller fragments that can't be tracked. This is precisely why Orbital Guardian AI exists.";
    }
    if (q.includes('iss') || q.includes('international space station')) return knowledgeBase.iss;
    if (q.includes('black hole')) return knowledgeBase.blackhole;
    if (q.includes('satellite')) return knowledgeBase.satellite;
    if (q.includes('debris') || q.includes('space junk')) return knowledgeBase.debris;
    if (q.includes('jupiter')) return knowledgeBase.jupiter || "Jupiter is the king of planets and contains over twice the mass of all other planets combined.";

    // Space weather
    if (q.includes('space weather') || q.includes('solar flare') || q.includes('geomagnetic')) {
      return "Space weather is driven by solar activity. Solar flares and coronal mass ejections release charged particles that interact with Earth's magnetic field. During high activity, the upper atmosphere expands, increasing drag on low-Earth-orbit satellites and changing their orbital paths. Elevated Kp index values indicate geomagnetic storm conditions. Currently monitoring Kp index at 3.2 — conditions are relatively quiet.";
    }

    // Starlink
    if (q.includes('starlink')) {
      return "SpaceX's Starlink constellation has deployed over 5,000 satellites in low Earth orbit at approximately 550 kilometers altitude. This represents the largest satellite constellation ever deployed. Starlink satellites include autonomous collision avoidance capabilities, but their sheer number significantly increases conjunction event frequency. Critics warn of impacts on astronomical observations and the long-term orbital environment.";
    }

    // Greetings
    if (q.includes('hello') || q.includes('hi') || q.includes('hey')) return ASTRA_RESPONSES.greeting;
    if (q.includes('help') || q.includes('what can you do')) return ASTRA_RESPONSES.help;

    return ASTRA_RESPONSES.default;
  };

  const sendMessage = (text) => {
    const msg = text || input.trim();
    if (!msg) return;

    const userMsg = { id: Date.now(), from: 'user', text: msg, time: new Date().toLocaleTimeString() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const response = getResponse(msg);
      const astraMsg = { id: Date.now() + 1, from: 'astra', text: response, time: new Date().toLocaleTimeString() };
      setMessages(prev => [...prev, astraMsg]);
      setIsTyping(false);
      speak(response);
    }, 800 + Math.random() * 400);
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      sendMessage(''); // Show helper
      return;
    }
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    recognition.onstart = () => setListening(true);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
      sendMessage(transcript);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognition.start();
  };

  if (!isOpen) {
    return (
      <button onClick={onToggle}
        style={{ position: 'fixed', bottom: '24px', right: '24px', zIndex: 999, width: '60px', height: '60px', borderRadius: '50%', background: 'linear-gradient(135deg, rgba(0,20,60,0.95), rgba(0,10,40,0.95))', border: '2px solid var(--accent-cyan)', color: 'var(--accent-cyan)', fontSize: '24px', cursor: 'pointer', boxShadow: 'var(--glow-cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s' }}
        className="anim-pulse"
        title="Open Astra AI Assistant">
        🤖
      </button>
    );
  }

  return (
    <div style={{ position: 'fixed', bottom: '24px', right: '24px', zIndex: 999, width: '380px', maxWidth: 'calc(100vw - 32px)', height: '560px', background: 'rgba(0,5,25,0.97)', border: '1px solid var(--border-glow)', borderRadius: '16px', display: 'flex', flexDirection: 'column', boxShadow: '0 0 40px rgba(0,245,255,0.15)', backdropFilter: 'blur(20px)', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border-subtle)', background: 'rgba(0,10,40,0.8)', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: 'linear-gradient(135deg, #0040a0, #0080ff)', border: '2px solid var(--accent-cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', flexShrink: 0, boxShadow: speaking ? 'var(--glow-cyan)' : 'none', transition: 'box-shadow 0.3s' }}>
          🤖
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px' }}>ASTRA</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--accent-green)', letterSpacing: '1px' }}>
            <span className="anim-blink">●</span> {speaking ? 'SPEAKING...' : listening ? 'LISTENING...' : 'ONLINE'}
          </div>
        </div>
        <button onClick={onToggle} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: '16px', padding: '4px' }}>✕</button>
      </div>

      {/* Quick commands */}
      <div style={{ padding: '8px 12px', borderBottom: '1px solid rgba(0,60,120,0.2)', display: 'flex', gap: '6px', overflowX: 'auto', scrollbarWidth: 'none' }}>
        {QUICK_COMMANDS.slice(0, 4).map(cmd => (
          <button key={cmd.cmd} onClick={() => sendMessage(cmd.cmd)}
            style={{ background: 'rgba(0,128,255,0.08)', border: '1px solid rgba(0,128,255,0.25)', borderRadius: '20px', padding: '4px 10px', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', fontSize: '9px', cursor: 'pointer', whiteSpace: 'nowrap', letterSpacing: '0.5px', transition: 'all 0.2s', flexShrink: 0 }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent-cyan)'; e.currentTarget.style.color = 'var(--accent-cyan)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(0,128,255,0.25)'; e.currentTarget.style.color = 'var(--text-secondary)'; }}>
            {cmd.label}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ display: 'flex', gap: '8px', alignItems: 'flex-start', flexDirection: msg.from === 'user' ? 'row-reverse' : 'row' }}>
            {msg.from === 'astra' && (
              <div style={{ width: '26px', height: '26px', borderRadius: '50%', background: 'rgba(0,60,160,0.8)', border: '1px solid var(--accent-cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', flexShrink: 0 }}>🤖</div>
            )}
            <div style={{ maxWidth: '80%', padding: '10px 12px', borderRadius: msg.from === 'user' ? '12px 4px 12px 12px' : '4px 12px 12px 12px', background: msg.from === 'user' ? 'rgba(0,100,200,0.25)' : 'rgba(0,20,60,0.8)', border: `1px solid ${msg.from === 'user' ? 'rgba(0,128,255,0.3)' : 'rgba(0,80,160,0.3)'}` }}>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-primary)', lineHeight: 1.55, margin: 0 }}>{msg.text}</p>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-dim)', marginTop: '4px', textAlign: msg.from === 'user' ? 'right' : 'left' }}>{msg.time}</div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <div style={{ width: '26px', height: '26px', borderRadius: '50%', background: 'rgba(0,60,160,0.8)', border: '1px solid var(--accent-cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px' }}>🤖</div>
            <div style={{ padding: '10px 14px', background: 'rgba(0,20,60,0.8)', border: '1px solid rgba(0,80,160,0.3)', borderRadius: '4px 12px 12px 12px', display: 'flex', gap: '4px', alignItems: 'center' }}>
              {[0, 1, 2].map(i => <div key={i} style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--accent-cyan)', animation: 'blink 1.2s infinite', animationDelay: `${i * 0.3}s` }} />)}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div style={{ padding: '12px', borderTop: '1px solid var(--border-subtle)', display: 'flex', gap: '8px' }}>
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage()}
          placeholder="Ask Astra anything..."
          style={{ flex: 1, background: 'rgba(0,10,40,0.8)', border: `1px solid ${listening ? 'var(--accent-green)' : 'var(--border-subtle)'}`, borderRadius: '8px', padding: '9px 12px', color: 'var(--text-primary)', fontFamily: 'var(--font-body)', fontSize: '13px', outline: 'none', transition: 'border-color 0.2s' }}
        />
        <button onClick={startListening}
          style={{ width: '38px', height: '38px', borderRadius: '8px', background: listening ? 'rgba(0,255,136,0.15)' : 'rgba(0,10,40,0.8)', border: `1px solid ${listening ? 'var(--accent-green)' : 'var(--border-subtle)'}`, color: listening ? 'var(--accent-green)' : 'var(--text-dim)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', flexShrink: 0 }}>
          🎙️
        </button>
        <button onClick={() => sendMessage()}
          style={{ width: '38px', height: '38px', borderRadius: '8px', background: 'rgba(0,128,255,0.15)', border: '1px solid rgba(0,128,255,0.4)', color: 'var(--accent-blue)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', flexShrink: 0 }}>
          ➤
        </button>
      </div>
    </div>
  );
}
