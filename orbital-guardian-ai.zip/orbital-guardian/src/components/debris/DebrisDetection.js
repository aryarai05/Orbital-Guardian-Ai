import React, { useState, useRef, useCallback } from 'react';
import { debrisData } from '../../data/spaceData';

const DEMO_IMAGES = [
  { name: 'debris_sample_1.jpg', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/The_Earth_seen_from_Apollo_17.jpg/240px-The_Earth_seen_from_Apollo_17.jpg', debrisCount: 7, threatScore: 73 },
  { name: 'orbit_scan_2.jpg', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/FullMoon2010.jpg/240px-FullMoon2010.jpg', debrisCount: 3, threatScore: 34 },
  { name: 'leo_capture_3.jpg', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/240px-PNG_transparency_demonstration_1.png', debrisCount: 12, threatScore: 91 },
];

export default function DebrisDetection() {
  const [uploadedImage, setUploadedImage] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState(null);
  const [selectedDemo, setSelectedDemo] = useState(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);

  const simulateDetection = useCallback((imageData, debrisCount, threatScore) => {
    setAnalyzing(true);
    setResults(null);

    setTimeout(() => {
      // Simulate ML bounding boxes
      const boxes = Array.from({ length: debrisCount }, (_, i) => ({
        id: i + 1,
        x: 10 + Math.random() * 70,
        y: 10 + Math.random() * 70,
        w: 3 + Math.random() * 12,
        h: 3 + Math.random() * 12,
        confidence: 0.65 + Math.random() * 0.34,
        size: ['<10cm', '10-100cm', '>100cm'][Math.floor(Math.random() * 3)],
        type: ['Paint flake', 'Rocket fragment', 'Satellite component', 'Unknown fragment'][Math.floor(Math.random() * 4)],
      }));

      const detectedResults = {
        debrisCount,
        threatScore,
        boxes,
        riskLevel: threatScore > 80 ? 'critical' : threatScore > 60 ? 'high' : threatScore > 40 ? 'medium' : 'low',
        model: 'YOLOv8-Space-v2.1',
        confidence: 94.2 + Math.random() * 5.8,
        processingTime: (0.3 + Math.random() * 0.8).toFixed(2),
        orbitZone: ['LEO', 'MEO', 'GEO'][Math.floor(Math.random() * 3)],
      };

      setResults(detectedResults);
      setAnalyzing(false);

      // Draw on canvas
      setTimeout(() => drawDetections(detectedResults), 100);
    }, 2500 + Math.random() * 1000);
  }, []);

  const drawDetections = (res) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;

    ctx.clearRect(0, 0, W, H);

    // Draw detection boxes
    res.boxes.forEach(box => {
      const x = (box.x / 100) * W;
      const y = (box.y / 100) * H;
      const w = (box.w / 100) * W;
      const h = (box.h / 100) * H;
      const color = box.confidence > 0.9 ? '#ff2244' : box.confidence > 0.75 ? '#ff8800' : '#ffcc00';

      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);

      // Corner markers
      const cl = 8;
      ctx.strokeStyle = '#00f5ff';
      ctx.lineWidth = 2;
      [[x, y], [x + w, y], [x, y + h], [x + w, y + h]].forEach(([cx, cy], i) => {
        ctx.beginPath();
        ctx.moveTo(cx + (i % 2 === 0 ? cl : -cl), cy);
        ctx.lineTo(cx, cy);
        ctx.lineTo(cx, cy + (i < 2 ? cl : -cl));
        ctx.stroke();
      });

      // Label
      ctx.fillStyle = color;
      ctx.font = '10px "Share Tech Mono"';
      ctx.fillText(`DEBRIS #${box.id} ${(box.confidence * 100).toFixed(0)}%`, x, y - 4);
    });
  };

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setUploadedImage(ev.target.result);
      setSelectedDemo(null);
      const count = 2 + Math.floor(Math.random() * 10);
      const threat = 20 + Math.floor(Math.random() * 75);
      simulateDetection(ev.target.result, count, threat);
    };
    reader.readAsDataURL(file);
  };

  const handleDemoSelect = (demo) => {
    setSelectedDemo(demo);
    setUploadedImage(demo.url);
    simulateDetection(demo.url, demo.debrisCount, demo.threatScore);
  };

  const currentImage = uploadedImage;

  return (
    <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
      {/* Header */}
      <div className="page-header" style={{ padding: '0 0 24px', borderBottom: '1px solid var(--border-subtle)', marginBottom: '28px' }}>
        <div style={{ fontSize: '36px', marginBottom: '8px' }}>🎯</div>
        <h1 className="section-title">AI DEBRIS DETECTION</h1>
        <p className="section-sub">YOLOv8-powered satellite imagery analysis · Real-time threat assessment</p>
      </div>

      <div className="grid-2" style={{ gap: '24px', alignItems: 'start' }}>
        {/* Upload + Image Area */}
        <div>
          {/* Upload Zone */}
          <div className="glass-card" style={{ padding: '24px', marginBottom: '20px' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>UPLOAD SATELLITE IMAGERY</h3>
            <div
              style={{ border: '2px dashed rgba(0,245,255,0.3)', borderRadius: '10px', padding: '32px', textAlign: 'center', cursor: 'pointer', transition: 'all 0.3s', background: 'rgba(0,10,40,0.4)' }}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={e => e.preventDefault()}
              onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) { fileInputRef.current.files = e.dataTransfer.files; handleFileUpload({ target: { files: [f] } }); } }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(0,245,255,0.7)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(0,245,255,0.3)'}
            >
              <div style={{ fontSize: '40px', marginBottom: '12px' }}>📡</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', marginBottom: '6px', letterSpacing: '2px' }}>DROP SATELLITE IMAGE HERE</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-dim)' }}>Supports PNG, JPG, TIFF · Max 50MB</div>
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} style={{ display: 'none' }} />

            {/* Demo samples */}
            <div style={{ marginTop: '16px' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '2px', marginBottom: '10px' }}>OR USE DEMO SAMPLES:</div>
              <div style={{ display: 'flex', gap: '8px' }}>
                {DEMO_IMAGES.map(demo => (
                  <button key={demo.name} className="btn-primary" style={{ flex: 1, padding: '8px 12px', fontSize: '10px', letterSpacing: '1px', borderColor: selectedDemo?.name === demo.name ? 'var(--accent-cyan)' : 'rgba(0,100,200,0.3)' }}
                    onClick={() => handleDemoSelect(demo)}>
                    {demo.name.split('.')[0].replace('_', ' ').toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Image with overlays */}
          <div className="glass-card" style={{ padding: '16px', position: 'relative' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '12px' }}>ANALYSIS VIEW</h3>
            <div style={{ position: 'relative', background: 'rgba(0,5,20,0.8)', borderRadius: '8px', overflow: 'hidden', minHeight: '280px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {currentImage ? (
                <>
                  <img src={currentImage} alt="satellite" style={{ width: '100%', height: '280px', objectFit: 'cover', display: 'block', filter: 'brightness(0.8) contrast(1.2) hue-rotate(180deg) saturate(0.5)' }} onError={e => e.target.style.display='none'} />
                  <canvas ref={canvasRef} width={500} height={280} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }} />
                  {analyzing && (
                    <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,10,30,0.7)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '16px' }}>
                      <div className="loading-spinner" />
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--accent-cyan)', letterSpacing: '2px' }}>RUNNING YOLOV8 ANALYSIS...</div>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)' }}>Scanning {Math.floor(Math.random() * 512 + 256)} image regions</div>
                    </div>
                  )}
                </>
              ) : (
                <div style={{ textAlign: 'center', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', fontSize: '12px' }}>
                  <div style={{ fontSize: '48px', marginBottom: '12px', opacity: 0.3 }}>🛸</div>
                  No image loaded
                </div>
              )}
            </div>
            {results && !analyzing && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '12px', padding: '8px 12px', background: 'rgba(0,10,40,0.6)', borderRadius: '6px' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)' }}>MODEL: {results.model}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-green)' }}>PROCESSED: {results.processingTime}s</span>
              </div>
            )}
          </div>
        </div>

        {/* Results Panel */}
        <div>
          {results && !analyzing ? (
            <>
              {/* Main metrics */}
              <div className="grid-2" style={{ marginBottom: '16px' }}>
                {[
                  { label: 'Debris Detected', value: results.debrisCount, icon: '🎯', color: 'var(--accent-orange)' },
                  { label: 'Threat Score', value: `${results.threatScore}/100`, icon: '⚠️', color: results.threatScore > 80 ? 'var(--accent-red)' : results.threatScore > 60 ? '#ff8800' : 'var(--accent-yellow)' },
                  { label: 'Model Confidence', value: `${results.confidence.toFixed(1)}%`, icon: '🤖', color: 'var(--accent-cyan)' },
                  { label: 'Orbit Zone', value: results.orbitZone, icon: '🌍', color: 'var(--accent-purple)' },
                ].map(m => (
                  <div key={m.label} className="metric-card">
                    <div style={{ fontSize: '20px', marginBottom: '4px' }}>{m.icon}</div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: m.color, fontWeight: 700 }}>{m.value}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px', marginTop: '2px' }}>{m.label.toUpperCase()}</div>
                  </div>
                ))}
              </div>

              {/* Risk gauge */}
              <div className="glass-card" style={{ padding: '16px', marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: 'var(--text-secondary)', letterSpacing: '1px' }}>THREAT ASSESSMENT</span>
                  <span className={`risk-badge ${results.riskLevel}`}>{results.riskLevel.toUpperCase()}</span>
                </div>
                <div className="progress-bar-bg" style={{ height: '10px', borderRadius: '8px' }}>
                  <div className="progress-bar-fill" style={{ width: `${results.threatScore}%`, background: results.threatScore > 80 ? 'linear-gradient(90deg, #ff8800, #ff2244)' : results.threatScore > 60 ? 'linear-gradient(90deg, #ffcc00, #ff8800)' : results.threatScore > 40 ? '#ffcc00' : 'var(--accent-green)', borderRadius: '8px', boxShadow: results.threatScore > 80 ? 'var(--glow-red)' : 'none' }} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '4px' }}>
                  {['SAFE', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map((l, i) => (
                    <span key={l} style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-dim)', letterSpacing: '1px' }}>{l}</span>
                  ))}
                </div>
              </div>

              {/* Detected objects table */}
              <div className="glass-card" style={{ padding: '16px' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '12px' }}>DETECTED OBJECTS ({results.debrisCount})</div>
                <div style={{ overflowX: 'auto' }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>TYPE</th>
                        <th>SIZE</th>
                        <th>CONF.</th>
                        <th>STATUS</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.boxes.slice(0, 8).map(box => (
                        <tr key={box.id}>
                          <td style={{ color: 'var(--accent-cyan)' }}>#{String(box.id).padStart(3, '0')}</td>
                          <td>{box.type}</td>
                          <td style={{ color: 'var(--text-secondary)' }}>{box.size}</td>
                          <td style={{ color: box.confidence > 0.9 ? 'var(--accent-red)' : box.confidence > 0.75 ? '#ff8800' : 'var(--accent-yellow)' }}>{(box.confidence * 100).toFixed(0)}%</td>
                          <td><span className={`risk-badge ${box.confidence > 0.9 ? 'critical' : box.confidence > 0.75 ? 'high' : 'medium'}`}>{box.confidence > 0.9 ? 'CRITICAL' : box.confidence > 0.75 ? 'HIGH' : 'MONITOR'}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : analyzing ? (
            <div className="loading-container" style={{ height: '400px' }}>
              <div className="loading-spinner" />
              <div className="loading-text">YOLOV8 PROCESSING</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px', textAlign: 'center', lineHeight: 1.8 }}>
                Initializing neural network...<br />
                Running object detection...<br />
                Calculating threat scores...
              </div>
            </div>
          ) : (
            <>
              <div className="glass-card" style={{ padding: '24px', marginBottom: '20px' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>HOW IT WORKS</div>
                {[
                  { step: '01', title: 'Image Input', desc: 'Upload satellite imagery in PNG, JPG, or TIFF format captured from orbital observation systems.' },
                  { step: '02', title: 'YOLOv8 Analysis', desc: 'State-of-the-art object detection model trained on 50,000+ labeled space debris images from ESA catalogues.' },
                  { step: '03', title: 'Threat Assessment', desc: 'AI calculates size estimates, orbital parameters, and collision risk scores for each detected object.' },
                  { step: '04', title: 'Visualization', desc: 'Results displayed with bounding boxes, confidence scores, and color-coded risk levels.' },
                ].map(s => (
                  <div key={s.step} style={{ display: 'flex', gap: '14px', marginBottom: '14px', paddingBottom: '14px', borderBottom: '1px solid rgba(0,60,120,0.2)' }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--accent-cyan)', opacity: 0.5, minWidth: '28px' }}>{s.step}</div>
                    <div>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--text-primary)', marginBottom: '4px' }}>{s.title}</div>
                      <div style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{s.desc}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Live catalog */}
              <div className="glass-card" style={{ padding: '16px' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '12px' }}>TRACKED DEBRIS CATALOG</div>
                <table className="data-table">
                  <thead><tr><th>Name</th><th>Alt (km)</th><th>Size (m)</th><th>Threat</th></tr></thead>
                  <tbody>
                    {debrisData.slice(0, 6).map(d => (
                      <tr key={d.id}>
                        <td style={{ color: 'var(--accent-cyan)', fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{d.name}</td>
                        <td>{d.altitude}</td>
                        <td>{d.size}</td>
                        <td><span className={`risk-badge ${d.risk}`}>{d.risk.toUpperCase()}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
