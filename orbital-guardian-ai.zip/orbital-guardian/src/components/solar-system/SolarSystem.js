import React, { useEffect, useRef, useState, useCallback } from 'react';
import { planetsData, sunData } from '../../data/planets';

export default function SolarSystem({ unlockAchievement }) {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const stateRef = useRef({ angles: {}, zoom: 1, offset: { x: 0, y: 0 }, isDragging: false, dragStart: { x: 0, y: 0 }, time: 0 });
  const [selectedPlanet, setSelectedPlanet] = useState(null);
  const [comparePlanet, setComparePlanet] = useState(null);
  const [showCompare, setShowCompare] = useState(false);
  const [focusPlanet, setFocusPlanet] = useState(null);

  const speak = useCallback((text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = 0.85; utter.pitch = 0.7; utter.volume = 0.8;
      window.speechSynthesis.speak(utter);
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const s = stateRef.current;
    planetsData.forEach(p => { s.angles[p.id] = Math.random() * Math.PI * 2; });

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const getPlanetColor = (id) => {
      const colors = { mercury: '#b5a595', venus: '#e8c87a', earth: '#4a9eff', mars: '#c1440e', jupiter: '#c88b3a', saturn: '#e4d191', uranus: '#7de8e8', neptune: '#4b70dd' };
      return colors[id] || '#ffffff';
    };

    const draw = () => {
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      s.time += 0.005;

      const cx = W / 2 + s.offset.x;
      const cy = H / 2 + s.offset.y;
      const baseScale = Math.min(W, H) / 1100 * s.zoom;

      // Draw orbit rings
      planetsData.forEach(p => {
        const orbitR = p.distance * baseScale * 50;
        ctx.beginPath();
        ctx.arc(cx, cy, orbitR, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(0, 80, 160, 0.15)';
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 8]);
        ctx.stroke();
        ctx.setLineDash([]);
      });

      // Asteroid belt
      for (let i = 0; i < 80; i++) {
        const baseAngle = (i / 80) * Math.PI * 2 + s.time * 0.01;
        const r = (20.5 + Math.sin(i * 7.3) * 1.5) * baseScale * 50;
        const ax = cx + Math.cos(baseAngle) * r;
        const ay = cy + Math.sin(baseAngle) * r * 0.35;
        ctx.beginPath();
        ctx.arc(ax, ay, 1, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(150, 130, 100, ${0.3 + Math.random() * 0.2})`;
        ctx.fill();
      }

      // Sun
      const sunGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 30 * baseScale * 10);
      sunGrad.addColorStop(0, '#fff5a0');
      sunGrad.addColorStop(0.3, '#ffd700');
      sunGrad.addColorStop(0.7, '#ff8c00');
      sunGrad.addColorStop(1, '#ff4500');
      ctx.beginPath();
      ctx.arc(cx, cy, 20 * baseScale * 10, 0, Math.PI * 2);
      ctx.fillStyle = sunGrad;
      ctx.shadowColor = '#ffaa00';
      ctx.shadowBlur = 40 * baseScale * 10;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Corona
      const coronaGrad = ctx.createRadialGradient(cx, cy, 20 * baseScale * 10, cx, cy, 40 * baseScale * 10);
      coronaGrad.addColorStop(0, 'rgba(255, 200, 50, 0.3)');
      coronaGrad.addColorStop(1, 'rgba(255, 100, 0, 0)');
      ctx.beginPath();
      ctx.arc(cx, cy, 40 * baseScale * 10, 0, Math.PI * 2);
      ctx.fillStyle = coronaGrad;
      ctx.fill();

      // Planets
      planetsData.forEach(p => {
        s.angles[p.id] = (s.angles[p.id] || 0) + p.speed * 0.01;
        const orbitR = p.distance * baseScale * 50;
        const px = cx + Math.cos(s.angles[p.id]) * orbitR;
        const py = cy + Math.sin(s.angles[p.id]) * orbitR * 0.35;
        const pr = Math.max(3, p.radius * baseScale * 25);
        const color = getPlanetColor(p.id);

        // Orbit trail
        ctx.beginPath();
        for (let t = 0; t < 40; t++) {
          const ta = s.angles[p.id] - t * 0.06;
          const tx = cx + Math.cos(ta) * orbitR;
          const ty = cy + Math.sin(ta) * orbitR * 0.35;
          if (t === 0) ctx.moveTo(tx, ty);
          else ctx.lineTo(tx, ty);
        }
        ctx.strokeStyle = `${color}33`;
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Saturn rings
        if (p.id === 'saturn') {
          ctx.save();
          ctx.translate(px, py);
          ctx.scale(1, 0.35);
          ctx.beginPath();
          ctx.arc(0, 0, pr * 2.2, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(228, 209, 145, 0.5)';
          ctx.lineWidth = pr * 0.4;
          ctx.stroke();
          ctx.restore();
        }

        // Planet glow
        const grad = ctx.createRadialGradient(px - pr * 0.3, py - pr * 0.3, 0, px, py, pr);
        grad.addColorStop(0, '#ffffff');
        grad.addColorStop(0.3, color);
        grad.addColorStop(1, color + '88');
        ctx.beginPath();
        ctx.arc(px, py, pr, 0, Math.PI * 2);
        ctx.fillStyle = grad;
        if (selectedPlanet?.id === p.id) {
          ctx.shadowColor = color;
          ctx.shadowBlur = 20;
        }
        ctx.fill();
        ctx.shadowBlur = 0;

        // Label
        if (baseScale > 0.3) {
          ctx.fillStyle = 'rgba(200, 220, 255, 0.8)';
          ctx.font = `${Math.max(10, 11 * baseScale)}px 'Share Tech Mono', monospace`;
          ctx.textAlign = 'center';
          ctx.fillText(p.name.toUpperCase(), px, py - pr - 6);
        }
      });

      animRef.current = requestAnimationFrame(draw);
    };

    draw();

    // Mouse interactions
    const handleWheel = (e) => {
      e.preventDefault();
      s.zoom = Math.max(0.3, Math.min(5, s.zoom * (e.deltaY < 0 ? 1.1 : 0.9)));
    };
    const handleMouseDown = (e) => {
      s.isDragging = true;
      s.dragStart = { x: e.clientX - s.offset.x, y: e.clientY - s.offset.y };
    };
    const handleMouseMove = (e) => {
      if (s.isDragging) {
        s.offset = { x: e.clientX - s.dragStart.x, y: e.clientY - s.dragStart.y };
      }
    };
    const handleMouseUp = () => { s.isDragging = false; };

    const handleClick = (e) => {
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const W = canvas.width, H = canvas.height;
      const cx = W / 2 + s.offset.x, cy = H / 2 + s.offset.y;
      const baseScale = Math.min(W, H) / 1100 * s.zoom;

      let clicked = null;
      planetsData.forEach(p => {
        const orbitR = p.distance * baseScale * 50;
        const px = cx + Math.cos(s.angles[p.id]) * orbitR;
        const py = cy + Math.sin(s.angles[p.id]) * orbitR * 0.35;
        const pr = Math.max(5, p.radius * baseScale * 25);
        const dist = Math.sqrt((mx - px) ** 2 + (my - py) ** 2);
        if (dist < pr + 10) clicked = p;
      });

      if (clicked) {
        setSelectedPlanet(clicked);
        speak(clicked.voiceText);
        unlockAchievement('planet-master');
      }
    };

    canvas.addEventListener('wheel', handleWheel, { passive: false });
    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('click', handleClick);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('wheel', handleWheel);
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('click', handleClick);
    };
  }, [speak, unlockAchievement]);

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 60px)', position: 'relative' }}>
      {/* Canvas */}
      <canvas ref={canvasRef} style={{ flex: 1, cursor: 'crosshair', background: 'transparent' }} />

      {/* Controls */}
      <div style={{ position: 'absolute', top: '16px', left: '16px', display: 'flex', gap: '8px' }}>
        {['ZOOM +', 'ZOOM -', 'RESET'].map((label, i) => (
          <button key={label} className="btn-primary" style={{ padding: '6px 14px', fontSize: '10px', letterSpacing: '1px' }}
            onClick={() => {
              const s = stateRef.current;
              if (i === 0) s.zoom = Math.min(5, s.zoom * 1.3);
              else if (i === 1) s.zoom = Math.max(0.3, s.zoom * 0.77);
              else { s.zoom = 1; s.offset = { x: 0, y: 0 }; }
            }}>
            {label}
          </button>
        ))}
        <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '10px', letterSpacing: '1px', borderColor: 'var(--accent-purple)', color: 'var(--accent-purple)' }}
          onClick={() => setShowCompare(!showCompare)}>
          COMPARE
        </button>
      </div>

      {/* Instructions */}
      <div style={{ position: 'absolute', bottom: '16px', left: '16px', fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px' }}>
        SCROLL to zoom · DRAG to pan · CLICK planet for info
      </div>

      {/* Planet list sidebar */}
      <div style={{ width: '160px', background: 'rgba(0,5,20,0.9)', borderLeft: '1px solid var(--border-subtle)', padding: '12px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '4px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '8px' }}>PLANETS</div>
        {planetsData.map(p => {
          const colors = { mercury: '#b5a595', venus: '#e8c87a', earth: '#4a9eff', mars: '#c1440e', jupiter: '#c88b3a', saturn: '#e4d191', uranus: '#7de8e8', neptune: '#4b70dd' };
          return (
            <button key={p.id} style={{ background: selectedPlanet?.id === p.id ? 'rgba(0,245,255,0.1)' : 'transparent', border: `1px solid ${selectedPlanet?.id === p.id ? 'var(--accent-cyan)' : 'transparent'}`, borderRadius: '6px', padding: '6px 8px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', color: 'inherit', transition: 'all 0.2s' }}
              onClick={() => { setSelectedPlanet(p); speak(p.voiceText); unlockAchievement('planet-master'); }}>
              <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: colors[p.id], flexShrink: 0 }} />
              <span style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'var(--text-secondary)' }}>{p.name}</span>
            </button>
          );
        })}
      </div>

      {/* Planet Info Panel */}
      {selectedPlanet && (
        <div style={{ position: 'absolute', top: '16px', right: '176px', width: '280px', background: 'rgba(0,5,25,0.95)', border: '1px solid var(--border-subtle)', borderRadius: '12px', padding: '20px', maxHeight: 'calc(100vh - 100px)', overflowY: 'auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--accent-cyan)', fontWeight: 700 }}>{selectedPlanet.name.toUpperCase()}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', marginTop: '2px' }}>PLANETARY DATA</div>
            </div>
            <button onClick={() => setSelectedPlanet(null)} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: '18px' }}>✕</button>
          </div>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '16px' }}>{selectedPlanet.description}</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px' }}>
            {[
              { label: 'Diameter', value: `${selectedPlanet.diameter.toLocaleString()} km` },
              { label: 'Gravity', value: `${selectedPlanet.gravity} m/s²` },
              { label: 'Avg Temp', value: `${selectedPlanet.temperature}°C` },
              { label: 'From Sun', value: `${selectedPlanet.distanceFromSun} M km` },
              { label: 'Moons', value: selectedPlanet.moons },
              { label: 'Year Length', value: `${selectedPlanet.orbitalPeriod} days` },
            ].map(d => (
              <div key={d.label} style={{ background: 'rgba(0,20,60,0.5)', borderRadius: '6px', padding: '8px' }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-dim)', letterSpacing: '1px', marginBottom: '2px' }}>{d.label.toUpperCase()}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)' }}>{d.value}</div>
              </div>
            ))}
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', marginBottom: '6px', letterSpacing: '1px' }}>ATMOSPHERE: {selectedPlanet.atmosphere}</div>
          <div style={{ marginBottom: '14px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '8px' }}>QUICK FACTS</div>
            {selectedPlanet.facts.map((f, i) => (
              <div key={i} style={{ display: 'flex', gap: '8px', marginBottom: '4px' }}>
                <span style={{ color: 'var(--accent-cyan)', fontSize: '12px', flexShrink: 0 }}>›</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-secondary)', lineHeight: 1.4 }}>{f}</span>
              </div>
            ))}
          </div>
          <button className="btn-primary" style={{ width: '100%', fontSize: '10px' }} onClick={() => speak(selectedPlanet.voiceText)}>
            🔊 VOICE NARRATION
          </button>
        </div>
      )}

      {/* Compare tool */}
      {showCompare && (
        <div style={{ position: 'absolute', bottom: '16px', left: '50%', transform: 'translateX(-50%)', background: 'rgba(0,5,25,0.95)', border: '1px solid rgba(128,0,255,0.4)', borderRadius: '12px', padding: '20px', width: '600px', maxWidth: 'calc(100vw - 200px)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-purple)', letterSpacing: '2px' }}>PLANET COMPARISON TOOL</div>
            <button onClick={() => setShowCompare(false)} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer' }}>✕</button>
          </div>
          <div className="grid-2">
            {[0, 1].map(idx => {
              const current = idx === 0 ? selectedPlanet : comparePlanet;
              return (
                <div key={idx}>
                  <select style={{ width: '100%', marginBottom: '12px' }} className="input-field"
                    value={current?.id || ''} onChange={e => { const p = planetsData.find(x => x.id === e.target.value); idx === 0 ? setSelectedPlanet(p) : setComparePlanet(p); }}>
                    <option value="">Select Planet</option>
                    {planetsData.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  {current && (
                    <div>
                      {[['Diameter', `${current.diameter.toLocaleString()} km`], ['Gravity', `${current.gravity} m/s²`], ['Temperature', `${current.temperature}°C`], ['Distance from Sun', `${current.distanceFromSun}M km`]].map(([l, v]) => (
                        <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid rgba(0,60,120,0.2)' }}>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-dim)' }}>{l}</span>
                          <span style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: 'var(--accent-cyan)' }}>{v}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
