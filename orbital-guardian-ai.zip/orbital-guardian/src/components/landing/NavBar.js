import React from 'react';

const navItems = [
  { id: 'dashboard', label: 'Mission Control', icon: '📡' },
  { id: 'solar-system', label: 'Solar System', icon: '🌍' },
  { id: 'debris', label: 'Debris Detection', icon: '🎯' },
  { id: 'collision', label: 'Collision AI', icon: '⚡' },
  { id: 'orbit', label: 'Orbit Sim', icon: '🛸' },
  { id: 'education', label: 'Space Academy', icon: '📚' },
  { id: 'why-matters', label: 'Why It Matters', icon: '⚠️' },
  { id: 'achievements', label: 'Achievements', icon: '🏆' },
];

export default function NavBar({ currentView, onNavigate }) {
  return (
    <nav className="navbar">
      <div className="navbar-logo">⬡ OG·AI</div>
      <div className="navbar-items">
        {navItems.map(item => (
          <button
            key={item.id}
            className={`nav-btn ${currentView === item.id ? 'active' : ''}`}
            onClick={() => onNavigate(item.id)}
          >
            <span style={{ marginRight: '4px' }}>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
