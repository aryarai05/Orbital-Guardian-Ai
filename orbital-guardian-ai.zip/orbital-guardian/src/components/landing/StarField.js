import React, { useMemo } from 'react';

export default function StarField() {
  const stars = useMemo(() => {
    return Array.from({ length: 200 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2.5 + 0.5,
      duration: Math.random() * 4 + 2,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.8 + 0.2,
    }));
  }, []);

  const shootingStars = useMemo(() => {
    return Array.from({ length: 5 }, (_, i) => ({
      id: i,
      top: Math.random() * 60 + '%',
      left: Math.random() * 30 + '%',
      delay: i * 3.5 + Math.random() * 2,
      duration: Math.random() * 2 + 3,
    }));
  }, []);

  return (
    <div className="starfield" aria-hidden="true">
      {stars.map(star => (
        <div
          key={star.id}
          className="star"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            animationDuration: `${star.duration}s`,
            animationDelay: `${star.delay}s`,
          }}
        />
      ))}
      {shootingStars.map(ss => (
        <div
          key={ss.id}
          className="shooting-star"
          style={{
            top: ss.top,
            left: ss.left,
            animationDelay: `${ss.delay}s`,
            animationDuration: `${ss.duration}s`,
          }}
        />
      ))}
      {/* Nebula glow effects */}
      <div style={{
        position: 'absolute', top: '10%', left: '20%',
        width: '300px', height: '200px',
        background: 'radial-gradient(ellipse, rgba(80,0,160,0.08) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />
      <div style={{
        position: 'absolute', top: '60%', right: '15%',
        width: '250px', height: '180px',
        background: 'radial-gradient(ellipse, rgba(0,80,200,0.07) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />
      <div style={{
        position: 'absolute', bottom: '20%', left: '40%',
        width: '400px', height: '300px',
        background: 'radial-gradient(ellipse, rgba(0,160,200,0.04) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />
    </div>
  );
}
