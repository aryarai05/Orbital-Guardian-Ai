import React, { useEffect, useRef, useState } from 'react';

export default function Landing({ onLaunch }) {
  const [introText, setIntroText] = useState('');
  const [showButtons, setShowButtons] = useState(false);
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const fullText = 'ORBITAL GUARDIAN AI IS ONLINE AND MONITORING EARTH\'S ORBITAL ENVIRONMENT.';

  useEffect(() => {
    // Typewriter effect
    let i = 0;
    const timer = setTimeout(() => {
      const interval = setInterval(() => {
        if (i < fullText.length) {
          setIntroText(fullText.slice(0, i + 1));
          i++;
        } else {
          clearInterval(interval);
          setTimeout(() => setShowButtons(true), 500);
        }
      }, 35);
      return () => clearInterval(interval);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let angle = 0;
    let particles = Array.from({ length: 60 }, () => ({
      angle: Math.random() * Math.PI * 2,
      radius: 160 + Math.random() * 120,
      speed: (Math.random() * 0.003 + 0.001) * (Math.random() > 0.5 ? 1 : -1),
      size: Math.random() * 3 + 1,
      opacity: Math.random() * 0.8 + 0.2,
      color: Math.random() > 0.5 ? '#00f5ff' : '#ffffff',
    }));
    let satellites = Array.from({ length: 8 }, (_, i) => ({
      angle: (i / 8) * Math.PI * 2,
      radius: 145 + (i % 3) * 20,
      speed: 0.004 + i * 0.001,
      size: 3,
    }));

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const drawEarth = (cx, cy, r) => {
      // Base ocean
      const earthGrad = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
      earthGrad.addColorStop(0, '#4a9eff');
      earthGrad.addColorStop(0.4, '#1a6ba0');
      earthGrad.addColorStop(0.7, '#0a3d6b');
      earthGrad.addColorStop(1, '#020820');
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = earthGrad;
      ctx.fill();

      // Atmosphere glow
      const atmGrad = ctx.createRadialGradient(cx, cy, r, cx, cy, r + 25);
      atmGrad.addColorStop(0, 'rgba(100, 180, 255, 0.3)');
      atmGrad.addColorStop(1, 'rgba(0, 80, 200, 0)');
      ctx.beginPath();
      ctx.arc(cx, cy, r + 25, 0, Math.PI * 2);
      ctx.fillStyle = atmGrad;
      ctx.fill();

      // Continents (simplified patches)
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.clip();

      const continentColor = 'rgba(34, 120, 40, 0.6)';
      // Rotated view of continents
      const drawLand = (x, y, w, h) => {
        ctx.beginPath();
        ctx.ellipse(cx + x, cy + y, w, h, angle * 0.3, 0, Math.PI * 2);
        ctx.fillStyle = continentColor;
        ctx.fill();
      };
      drawLand(-20, -15, 18, 28);
      drawLand(25, -20, 22, 20);
      drawLand(-35, 20, 20, 16);
      drawLand(10, 5, 28, 18);
      drawLand(35, 10, 10, 15);
      drawLand(-15, -40, 15, 12);

      // Cloud layer
      ctx.globalAlpha = 0.4;
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      const cloudDraw = (x, y, w, h) => {
        ctx.beginPath();
        ctx.ellipse(cx + x, cy + y, w, h, angle * 0.5 + 0.3, 0, Math.PI * 2);
        ctx.fill();
      };
      cloudDraw(-30, -30, 25, 8);
      cloudDraw(20, 15, 20, 6);
      cloudDraw(-10, 30, 30, 7);
      cloudDraw(30, -10, 18, 5);
      ctx.globalAlpha = 1;
      ctx.restore();

      // Night side shadow
      const shadowGrad = ctx.createRadialGradient(cx + r * 0.5, cy, 0, cx + r * 0.3, cy, r * 1.2);
      shadowGrad.addColorStop(0, 'rgba(0,0,10,0)');
      shadowGrad.addColorStop(0.6, 'rgba(0,0,10,0)');
      shadowGrad.addColorStop(1, 'rgba(0,0,10,0.85)');
      ctx.beginPath();
      ctx.arc(cx, cy, r + 1, 0, Math.PI * 2);
      ctx.fillStyle = shadowGrad;
      ctx.fill();
    };

    const draw = () => {
      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2;
      const earthR = Math.min(W, H) * 0.22;

      angle += 0.003;

      // Orbit rings
      [1.5, 2, 2.7].forEach(mul => {
        ctx.beginPath();
        ctx.arc(cx, cy, earthR * mul, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(0, 100, 200, 0.15)';
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      drawEarth(cx, cy, earthR);

      // Satellites
      satellites.forEach(sat => {
        sat.angle += sat.speed;
        const sx = cx + Math.cos(sat.angle) * sat.radius * (earthR / 130);
        const sy = cy + Math.sin(sat.angle) * sat.radius * 0.35 * (earthR / 130);
        ctx.beginPath();
        ctx.arc(sx, sy, sat.size, 0, Math.PI * 2);
        ctx.fillStyle = '#00f5ff';
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Solar panel wings
        ctx.fillStyle = 'rgba(0, 200, 255, 0.6)';
        ctx.fillRect(sx - 8, sy - 1, 6, 2);
        ctx.fillRect(sx + 2, sy - 1, 6, 2);
      });

      // Debris particles
      particles.forEach(p => {
        p.angle += p.speed;
        const px = cx + Math.cos(p.angle) * p.radius * (earthR / 130);
        const py = cy + Math.sin(p.angle) * p.radius * 0.4 * (earthR / 130);
        ctx.beginPath();
        ctx.arc(px, py, p.size * 0.5, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.opacity * 0.7;
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      animRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animRef.current);
    };
  }, []);

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = 0.85;
      utter.pitch = 0.7;
      utter.volume = 0.8;
      window.speechSynthesis.speak(utter);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative', zIndex: 1, padding: '20px' }}>
      {/* Top status bar */}
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: '40px', background: 'rgba(0,5,20,0.9)', borderBottom: '1px solid rgba(0,245,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', zIndex: 100 }}>
        <div style={{ display: 'flex', gap: '20px' }}>
          {['SYS: ONLINE', 'ORBIT: TRACKING', 'AI: ACTIVE'].map(s => (
            <span key={s} style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-green)', letterSpacing: '2px' }}>
              <span className="anim-blink">●</span> {s}
            </span>
          ))}
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '2px' }}>
          {new Date().toUTCString().replace('GMT', 'UTC')}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '40px', maxWidth: '900px', width: '100%', marginTop: '40px' }}>
        {/* Earth Canvas */}
        <div style={{ position: 'relative', width: '320px', height: '320px' }}>
          <canvas ref={canvasRef} style={{ width: '100%', height: '100%', borderRadius: '50%' }} />
          {/* Corner decorations */}
          {[['0,0', '0,0'], ['0,100%', '0,0'], ['100%,0', '100%,0'], ['100%,100%', '100%,100%']].map(([pos, origin], i) => {
            const [t, l] = pos.split(',');
            return (
              <div key={i} style={{
                position: 'absolute', top: t, left: l, width: '20px', height: '20px',
                borderTop: i < 2 ? '2px solid var(--accent-cyan)' : 'none',
                borderBottom: i >= 2 ? '2px solid var(--accent-cyan)' : 'none',
                borderLeft: [0, 2].includes(i) ? '2px solid var(--accent-cyan)' : 'none',
                borderRight: [1, 3].includes(i) ? '2px solid var(--accent-cyan)' : 'none',
                opacity: 0.7,
              }} />
            );
          })}
        </div>

        {/* Title */}
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(24px,5vw,52px)', fontWeight: 900, color: 'var(--accent-cyan)', textShadow: 'var(--glow-cyan)', letterSpacing: '4px', marginBottom: '8px' }}>
            ORBITAL GUARDIAN AI
          </div>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: 'clamp(12px,2vw,16px)', color: 'var(--text-secondary)', letterSpacing: '4px', textTransform: 'uppercase', marginBottom: '24px' }}>
            Predicting Space Debris Threats Before They Happen
          </div>

          {/* Typewriter voice text */}
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--accent-green)', letterSpacing: '2px', minHeight: '24px', maxWidth: '600px', margin: '0 auto 8px' }}>
            <span style={{ color: 'rgba(0,255,136,0.5)' }}>ASTRA: </span>
            {introText}<span className="anim-blink">_</span>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', gap: '24px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {[
            { v: '27,852', l: 'Tracked Debris' },
            { v: '7,892', l: 'Active Satellites' },
            { v: '147', l: 'Potential Threats' },
            { v: '99.7%', l: 'AI Accuracy' },
          ].map(s => (
            <div key={s.l} style={{ textAlign: 'center', minWidth: '100px' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'var(--accent-cyan)', fontWeight: 700 }}>{s.v}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '2px', textTransform: 'uppercase' }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Buttons */}
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', justifyContent: 'center', opacity: showButtons ? 1 : 0, transform: showButtons ? 'translateY(0)' : 'translateY(20px)', transition: 'all 0.6s ease' }}>
          <button className="btn-primary" onClick={onLaunch} style={{ fontSize: '14px', padding: '14px 40px', letterSpacing: '4px' }}>
            🚀 LAUNCH MISSION
          </button>
          <button
            className="btn-primary"
            style={{ background: 'rgba(128,0,255,0.1)', borderColor: 'var(--accent-purple)', color: 'var(--accent-purple)' }}
            onClick={() => speak("Welcome Commander. Orbital Guardian AI is online and monitoring Earth's orbital environment. Over 27,000 pieces of space debris are currently being tracked in real time. Three high-risk conjunction events have been detected in the next 48 hours. Mission Control is standing by.")}
          >
            🔊 VOICE INTRO
          </button>
        </div>

        {/* Tech badges */}
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center' }}>
          {['Three.js', 'YOLOv8', 'React', 'AI/ML', 'WebGL', 'NASA Data'].map(t => (
            <span key={t} className="tag">{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
