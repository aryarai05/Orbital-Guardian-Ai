import React, { useEffect, useRef, useState } from 'react';
import { satellitesData, debrisData } from '../../data/spaceData';

export default function OrbitSimulation() {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const stateRef = useRef({ time: 0, zoom: 1, paused: false, selected: null });
  const [selectedObj, setSelectedObj] = useState(null);
  const [simSpeed, setSimSpeed] = useState(1);
  const [showDebris, setShowDebris] = useState(true);
  const [showSatellites, setShowSatellites] = useState(true);
  const [showTrails, setShowTrails] = useState(true);
  const speedRef = useRef(1);
  const trailsRef = useRef({});

  useEffect(() => { speedRef.current = simSpeed; }, [simSpeed]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const s = stateRef.current;

    // Initialize orbital angles
    const satAngles = {};
    const debAngles = {};
    satellitesData.forEach((sat, i) => { satAngles[sat.id] = (i / satellitesData.length) * Math.PI * 2; });
    debrisData.forEach((d, i) => { debAngles[d.id] = (i / debrisData.length) * Math.PI * 2 + 0.5; });

    const resize = () => { canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight; };
    resize();
    window.addEventListener('resize', resize);

    const getAltColor = (alt) => {
      if (alt < 500) return '#ff2244';
      if (alt < 1000) return '#ff8800';
      if (alt < 5000) return '#ffcc00';
      return '#00ff88';
    };

    const altToRadius = (alt, cx, cy) => {
      const minR = Math.min(cx, cy) * 0.22;
      const scale = Math.min(cx, cy) * 0.0006 * s.zoom;
      return minR + alt * scale;
    };

    const draw = () => {
      if (s.paused) { animRef.current = requestAnimationFrame(draw); return; }
      s.time += 0.008 * speedRef.current;

      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2;
      const earthR = Math.min(cx, cy) * 0.2;

      // Earth
      const earthGrad = ctx.createRadialGradient(cx - earthR * 0.3, cy - earthR * 0.3, earthR * 0.1, cx, cy, earthR);
      earthGrad.addColorStop(0, '#6ab4ff');
      earthGrad.addColorStop(0.4, '#1a6ba0');
      earthGrad.addColorStop(0.8, '#0a3d6b');
      earthGrad.addColorStop(1, '#020820');
      ctx.beginPath();
      ctx.arc(cx, cy, earthR, 0, Math.PI * 2);
      ctx.fillStyle = earthGrad;
      ctx.fill();

      // Atmosphere
      const atmGrad = ctx.createRadialGradient(cx, cy, earthR, cx, cy, earthR + 18);
      atmGrad.addColorStop(0, 'rgba(80,160,255,0.25)');
      atmGrad.addColorStop(1, 'rgba(0,60,200,0)');
      ctx.beginPath();
      ctx.arc(cx, cy, earthR + 18, 0, Math.PI * 2);
      ctx.fillStyle = atmGrad;
      ctx.fill();

      // Orbit shell bands (LEO, MEO, GEO labels)
      const zones = [
        { alt: 600, label: 'LEO', color: 'rgba(255,34,68,0.08)' },
        { alt: 2000, label: 'MEO', color: 'rgba(255,136,0,0.05)' },
        { alt: 20000, label: 'GEO', color: 'rgba(0,128,255,0.04)' },
      ];
      zones.forEach(z => {
        const r = altToRadius(z.alt, cx, cy);
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = z.color.replace('0.0', '0.15');
        ctx.lineWidth = 0.5;
        ctx.setLineDash([6, 12]);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(80,120,180,0.4)';
        ctx.font = '9px "Share Tech Mono"';
        ctx.fillText(z.label, cx + r - 24, cy - 6);
      });

      // Satellites
      if (showSatellites) {
        satellitesData.forEach(sat => {
          satAngles[sat.id] = (satAngles[sat.id] + (0.003 / Math.sqrt(sat.altitude / 400))) * speedRef.current * 0.008 + satAngles[sat.id];
          // Recalc properly
          satAngles[sat.id] += (0.003 / Math.sqrt(sat.altitude / 400)) * speedRef.current * 0.008;
          const r = altToRadius(sat.altitude, cx, cy);
          const sx = cx + Math.cos(satAngles[sat.id]) * r;
          const sy = cy + Math.sin(satAngles[sat.id]) * r;

          // Trail
          if (showTrails) {
            if (!trailsRef.current[`sat_${sat.id}`]) trailsRef.current[`sat_${sat.id}`] = [];
            const trail = trailsRef.current[`sat_${sat.id}`];
            trail.push({ x: sx, y: sy });
            if (trail.length > 60) trail.shift();
            if (trail.length > 2) {
              ctx.beginPath();
              trail.forEach((pt, i) => i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y));
              ctx.strokeStyle = `rgba(0, 245, 255, 0.2)`;
              ctx.lineWidth = 1;
              ctx.stroke();
            }
          }

          // Satellite dot
          ctx.beginPath();
          ctx.arc(sx, sy, 4, 0, Math.PI * 2);
          ctx.fillStyle = '#00f5ff';
          ctx.shadowColor = '#00f5ff';
          ctx.shadowBlur = 8;
          ctx.fill();
          ctx.shadowBlur = 0;

          // Solar panels
          ctx.fillStyle = 'rgba(0,200,255,0.6)';
          ctx.fillRect(sx - 9, sy - 1.5, 6, 3);
          ctx.fillRect(sx + 3, sy - 1.5, 6, 3);

          // Label
          ctx.fillStyle = 'rgba(150,200,255,0.6)';
          ctx.font = '9px "Share Tech Mono"';
          ctx.fillText(sat.name.slice(0, 8), sx + 6, sy - 4);
        });
      }

      // Debris
      if (showDebris) {
        debrisData.forEach(d => {
          debAngles[d.id] += (0.002 / Math.sqrt(d.altitude / 400)) * speedRef.current * 0.012 * (d.id % 2 === 0 ? 1 : -1.05);
          const r = altToRadius(d.altitude, cx, cy);
          const dx = cx + Math.cos(debAngles[d.id]) * r;
          const dy = cy + Math.sin(debAngles[d.id]) * r;

          // Debris trail (red/orange for dangerous)
          if (showTrails && d.risk === 'critical') {
            if (!trailsRef.current[`deb_${d.id}`]) trailsRef.current[`deb_${d.id}`] = [];
            const trail = trailsRef.current[`deb_${d.id}`];
            trail.push({ x: dx, y: dy });
            if (trail.length > 40) trail.shift();
            if (trail.length > 2) {
              ctx.beginPath();
              trail.forEach((pt, i) => i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y));
              ctx.strokeStyle = `rgba(255, 34, 68, 0.3)`;
              ctx.lineWidth = 1;
              ctx.stroke();
            }
          }

          const color = getAltColor(d.altitude);
          ctx.beginPath();
          ctx.arc(dx, dy, d.risk === 'critical' ? 3.5 : 2, 0, Math.PI * 2);
          ctx.fillStyle = color;
          if (d.risk === 'critical') {
            ctx.shadowColor = color;
            ctx.shadowBlur = 12;
          }
          ctx.fill();
          ctx.shadowBlur = 0;
        });
      }

      // Collision path warning lines
      const critDebris = debrisData.filter(d => d.risk === 'critical');
      critDebris.forEach(d => {
        const r = altToRadius(d.altitude, cx, cy);
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(255,34,68,0.15)';
        ctx.lineWidth = 6;
        ctx.stroke();
      });

      // Legend
      ctx.fillStyle = 'rgba(0,245,255,0.8)';
      ctx.font = '10px "Share Tech Mono"';
      ctx.fillText('● SATELLITE', 12, H - 60);
      ctx.fillStyle = 'rgba(255,34,68,0.8)';
      ctx.fillText('● CRITICAL DEBRIS', 12, H - 45);
      ctx.fillStyle = 'rgba(255,136,0,0.8)';
      ctx.fillText('● HIGH RISK DEBRIS', 12, H - 30);
      ctx.fillStyle = 'rgba(0,255,136,0.8)';
      ctx.fillText('● LOW RISK DEBRIS', 12, H - 15);

      animRef.current = requestAnimationFrame(draw);
    };

    // Fix angle update — separate from draw for cleaner logic
    satellitesData.forEach((sat, i) => { satAngles[sat.id] = (i / satellitesData.length) * Math.PI * 2; });
    debrisData.forEach((d, i) => { debAngles[d.id] = (i / debrisData.length) * Math.PI * 2 + 0.5; });

    // Rewrite draw with proper angle management
    let satA = {};
    let debA = {};
    satellitesData.forEach((sat, i) => { satA[sat.id] = (i / satellitesData.length) * Math.PI * 2; });
    debrisData.forEach((d, i) => { debA[d.id] = (i / debrisData.length) * Math.PI * 2 + 0.5; });

    cancelAnimationFrame(animRef.current);

    const drawClean = () => {
      if (s.paused) { animRef.current = requestAnimationFrame(drawClean); return; }

      const W = canvas.width, H = canvas.height;
      ctx.clearRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2;
      const earthR = Math.min(cx, cy) * 0.2;

      const earthGrad = ctx.createRadialGradient(cx - earthR * 0.3, cy - earthR * 0.3, earthR * 0.1, cx, cy, earthR);
      earthGrad.addColorStop(0, '#6ab4ff');
      earthGrad.addColorStop(0.4, '#1a6ba0');
      earthGrad.addColorStop(0.8, '#0a3d6b');
      earthGrad.addColorStop(1, '#020820');
      ctx.beginPath(); ctx.arc(cx, cy, earthR, 0, Math.PI * 2);
      ctx.fillStyle = earthGrad; ctx.fill();

      const atmGrad2 = ctx.createRadialGradient(cx, cy, earthR, cx, cy, earthR + 18);
      atmGrad2.addColorStop(0, 'rgba(80,160,255,0.25)');
      atmGrad2.addColorStop(1, 'rgba(0,60,200,0)');
      ctx.beginPath(); ctx.arc(cx, cy, earthR + 18, 0, Math.PI * 2);
      ctx.fillStyle = atmGrad2; ctx.fill();

      // Zone rings
      [{ alt: 600, label: 'LEO' }, { alt: 3000, label: 'MEO' }, { alt: 36000, label: 'GEO' }].forEach(z => {
        const r = earthR + (z.alt / 40000) * Math.min(cx, cy) * 0.75 * s.zoom;
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(0,80,160,0.15)'; ctx.lineWidth = 1;
        ctx.setLineDash([4, 10]); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(80,120,200,0.4)'; ctx.font = '9px "Share Tech Mono"';
        ctx.fillText(z.label, cx + r - 20, cy - 4);
      });

      const getR = (alt) => earthR + (alt / 40000) * Math.min(cx, cy) * 0.75 * s.zoom;

      // Satellites
      if (showSatellites) {
        satellitesData.forEach(sat => {
          satA[sat.id] += (0.004 / Math.sqrt(sat.altitude / 400)) * speedRef.current;
          const r = getR(sat.altitude);
          const sx = cx + Math.cos(satA[sat.id]) * r;
          const sy = cy + Math.sin(satA[sat.id]) * r * 0.9;

          if (showTrails) {
            if (!trailsRef.current[`s${sat.id}`]) trailsRef.current[`s${sat.id}`] = [];
            const tr = trailsRef.current[`s${sat.id}`];
            tr.push({ x: sx, y: sy });
            if (tr.length > 80) tr.shift();
            if (tr.length > 1) {
              ctx.beginPath();
              tr.forEach((pt, i) => { if (i === 0) ctx.moveTo(pt.x, pt.y); else ctx.lineTo(pt.x, pt.y); });
              ctx.strokeStyle = 'rgba(0,245,255,0.18)'; ctx.lineWidth = 1.5; ctx.stroke();
            }
          }

          ctx.beginPath(); ctx.arc(sx, sy, 4, 0, Math.PI * 2);
          ctx.fillStyle = '#00f5ff'; ctx.shadowColor = '#00f5ff'; ctx.shadowBlur = 10; ctx.fill(); ctx.shadowBlur = 0;
          ctx.fillStyle = 'rgba(0,200,255,0.7)';
          ctx.fillRect(sx - 9, sy - 1.5, 6, 3); ctx.fillRect(sx + 3, sy - 1.5, 6, 3);
          ctx.fillStyle = 'rgba(150,210,255,0.55)'; ctx.font = '9px "Share Tech Mono"';
          ctx.fillText(sat.name.length > 10 ? sat.name.slice(0, 9) + '…' : sat.name, sx + 7, sy - 3);
        });
      }

      // Debris
      if (showDebris) {
        debrisData.forEach(d => {
          debA[d.id] += (0.006 / Math.sqrt(d.altitude / 400)) * speedRef.current * (d.id % 2 === 0 ? 1 : -1.02);
          const r = getR(d.altitude);
          const dx2 = cx + Math.cos(debA[d.id]) * r;
          const dy2 = cy + Math.sin(debA[d.id]) * r * 0.88;

          if (showTrails && (d.risk === 'critical' || d.risk === 'high')) {
            if (!trailsRef.current[`d${d.id}`]) trailsRef.current[`d${d.id}`] = [];
            const tr = trailsRef.current[`d${d.id}`];
            tr.push({ x: dx2, y: dy2 });
            if (tr.length > 50) tr.shift();
            if (tr.length > 1) {
              ctx.beginPath();
              tr.forEach((pt, i) => { if (i === 0) ctx.moveTo(pt.x, pt.y); else ctx.lineTo(pt.x, pt.y); });
              ctx.strokeStyle = d.risk === 'critical' ? 'rgba(255,34,68,0.3)' : 'rgba(255,136,0,0.2)';
              ctx.lineWidth = 1.2; ctx.stroke();
            }
          }

          const col = d.risk === 'critical' ? '#ff2244' : d.risk === 'high' ? '#ff8800' : d.risk === 'medium' ? '#ffcc00' : '#00ff88';
          ctx.beginPath(); ctx.arc(dx2, dy2, d.risk === 'critical' ? 3.5 : 2.5, 0, Math.PI * 2);
          ctx.fillStyle = col;
          if (d.risk === 'critical') { ctx.shadowColor = col; ctx.shadowBlur = 14; }
          ctx.fill(); ctx.shadowBlur = 0;
        });

        // Warning rings for critical debris altitude bands
        debrisData.filter(d => d.risk === 'critical').forEach(d => {
          const r = getR(d.altitude);
          ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(255,34,68,0.12)'; ctx.lineWidth = 8; ctx.stroke();
        });
      }

      // Legend
      const legendItems = [
        { col: '#00f5ff', label: 'SATELLITE' },
        { col: '#ff2244', label: 'CRITICAL DEBRIS' },
        { col: '#ff8800', label: 'HIGH RISK' },
        { col: '#ffcc00', label: 'MEDIUM RISK' },
        { col: '#00ff88', label: 'LOW RISK' },
      ];
      legendItems.forEach((l, i) => {
        ctx.beginPath(); ctx.arc(14, H - 80 + i * 15, 4, 0, Math.PI * 2);
        ctx.fillStyle = l.col; ctx.fill();
        ctx.fillStyle = 'rgba(180,210,240,0.6)'; ctx.font = '9px "Share Tech Mono"';
        ctx.fillText(l.label, 24, H - 76 + i * 15);
      });

      animRef.current = requestAnimationFrame(drawClean);
    };

    drawClean();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [showDebris, showSatellites, showTrails]);

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 60px)', flexDirection: 'column' }}>
      {/* Controls bar */}
      <div style={{ padding: '12px 24px', background: 'rgba(0,5,20,0.9)', borderBottom: '1px solid var(--border-subtle)', display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px' }}>🛸 ORBIT SIMULATION</div>
        <div style={{ display: 'flex', gap: '8px', marginLeft: '8px' }}>
          <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '10px' }} onClick={() => stateRef.current.paused = !stateRef.current.paused}>
            {stateRef.current.paused ? '▶ RESUME' : '⏸ PAUSE'}
          </button>
          {[
            { label: '🛸 Satellites', active: showSatellites, toggle: () => setShowSatellites(p => !p) },
            { label: '☄ Debris', active: showDebris, toggle: () => setShowDebris(p => !p) },
            { label: '〰 Trails', active: showTrails, toggle: () => setShowTrails(p => !p) },
          ].map(b => (
            <button key={b.label} onClick={b.toggle} style={{ background: b.active ? 'rgba(0,245,255,0.1)' : 'transparent', border: `1px solid ${b.active ? 'var(--accent-cyan)' : 'rgba(0,100,200,0.3)'}`, borderRadius: '4px', padding: '6px 12px', color: b.active ? 'var(--accent-cyan)' : 'var(--text-secondary)', fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '1px', cursor: 'pointer', transition: 'all 0.2s' }}>
              {b.label}
            </button>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginLeft: 'auto' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)' }}>SIM SPEED: {simSpeed}×</span>
          <input type="range" className="range-slider" min={0.1} max={10} step={0.1} value={simSpeed} onChange={e => setSimSpeed(parseFloat(e.target.value))} style={{ width: '100px' }} />
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          {[
            { col: '#ff2244', label: `${debrisData.filter(d => d.risk === 'critical').length} Critical` },
            { col: '#ff8800', label: `${debrisData.filter(d => d.risk === 'high').length} High Risk` },
            { col: '#00f5ff', label: `${satellitesData.length} Satellites` },
          ].map(s => (
            <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: s.col, boxShadow: `0 0 6px ${s.col}` }} />
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-secondary)' }}>{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Canvas */}
      <canvas ref={canvasRef} style={{ flex: 1, cursor: 'crosshair', background: 'transparent' }} />
    </div>
  );
}
