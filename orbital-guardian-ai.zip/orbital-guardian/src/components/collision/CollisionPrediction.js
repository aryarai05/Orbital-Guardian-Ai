import React, { useState } from 'react';
import { collisionPredictions, debrisData, satellitesData } from '../../data/spaceData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter, ZAxis } from 'recharts';

export default function CollisionPrediction() {
  const [inputs, setInputs] = useState({ satSpeed: 7.66, satAlt: 408, debrisVel: 7.65, debrisAlt: 412, debris: 'Debris Alpha-7', satellite: 'ISS' });
  const [prediction, setPrediction] = useState(null);
  const [calculating, setCalculating] = useState(false);

  const calculateCollision = () => {
    setCalculating(true);
    setPrediction(null);
    setTimeout(() => {
      const altDiff = Math.abs(inputs.satAlt - inputs.debrisAlt);
      const velDiff = Math.abs(inputs.satSpeed - inputs.debrisVel);
      const relVel = Math.sqrt((inputs.satSpeed - inputs.debrisVel) ** 2 * 10 + altDiff ** 2 * 0.01);
      const baseProbability = Math.max(0.1, Math.min(99, (10 / (altDiff + 1)) * (1 + velDiff * 2) * (1 + Math.random() * 0.5)));
      const finalProb = parseFloat(baseProbability.toFixed(2));
      const riskLevel = finalProb > 20 ? 'red' : finalProb > 10 ? 'orange' : finalProb > 3 ? 'yellow' : 'green';
      const hoursToEncounter = Math.max(1, Math.floor(100 / (finalProb + 1) * (1 + Math.random())));

      setPrediction({
        probability: finalProb,
        riskLevel,
        timeToEncounter: `${hoursToEncounter}h ${Math.floor(Math.random() * 59)}m`,
        relativeVelocity: relVel.toFixed(2),
        closestApproach: (altDiff * 0.1 + Math.random() * 2).toFixed(1),
        kineticEnergy: ((0.5 * 500 * relVel ** 2) / 1e9).toFixed(1),
        fragmentsIfImpact: Math.floor(5000 + Math.random() * 50000),
        insight: finalProb > 20 ? `CRITICAL: ${inputs.satellite} is at severe risk from ${inputs.debris}. Immediate maneuver required to avoid catastrophic collision.` :
          finalProb > 10 ? `HIGH RISK: ${inputs.debris} poses significant threat to ${inputs.satellite}. Collision avoidance maneuver recommended within next 6 hours.` :
          finalProb > 3 ? `ELEVATED: ${inputs.debris} trajectory monitored. Low probability conjunction detected for ${inputs.satellite}.` :
          `NOMINAL: Current trajectory analysis shows minimal collision risk. ${inputs.satellite} orbital path is clear of ${inputs.debris}.`,
      });
      setCalculating(false);
    }, 2000);
  };

  const scatterData = debrisData.map(d => ({
    x: d.altitude,
    y: d.velocity,
    z: d.threatScore,
    name: d.name,
    risk: d.risk,
  }));

  const probChartData = collisionPredictions.map(c => ({
    name: c.satellite.replace(' ', '\n'),
    probability: c.probability,
    fill: c.riskLevel === 'red' ? '#ff2244' : c.riskLevel === 'orange' ? '#ff6600' : c.riskLevel === 'yellow' ? '#ffcc00' : '#00ff88',
  }));

  return (
    <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
      <div style={{ marginBottom: '28px' }}>
        <div style={{ fontSize: '36px', marginBottom: '8px' }}>⚡</div>
        <h1 className="section-title">COLLISION PREDICTION AI</h1>
        <p className="section-sub">ML-powered trajectory analysis · Conjunction probability calculation</p>
      </div>

      <div className="grid-2" style={{ gap: '24px', marginBottom: '24px' }}>
        {/* Input Form */}
        <div className="glass-card" style={{ padding: '24px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '20px' }}>TRAJECTORY PARAMETERS</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div className="grid-2">
              <div>
                <label style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px', display: 'block', marginBottom: '6px' }}>SATELLITE</label>
                <select className="input-field" value={inputs.satellite} onChange={e => { const sat = satellitesData.find(s => s.name === e.target.value); setInputs(p => ({ ...p, satellite: e.target.value, satAlt: sat?.altitude || p.satAlt, satSpeed: sat?.velocity || p.satSpeed })); }}>
                  {satellitesData.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px', display: 'block', marginBottom: '6px' }}>DEBRIS OBJECT</label>
                <select className="input-field" value={inputs.debris} onChange={e => { const d = debrisData.find(x => x.name === e.target.value); setInputs(p => ({ ...p, debris: e.target.value, debrisVel: d?.velocity || p.debrisVel, debrisAlt: d?.altitude || p.debrisAlt })); }}>
                  {debrisData.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                </select>
              </div>
            </div>

            {[
              { label: 'Satellite Speed (km/s)', key: 'satSpeed', min: 3, max: 11, step: 0.01 },
              { label: 'Satellite Altitude (km)', key: 'satAlt', min: 200, max: 40000, step: 10 },
              { label: 'Debris Velocity (km/s)', key: 'debrisVel', min: 3, max: 11, step: 0.01 },
              { label: 'Debris Altitude (km)', key: 'debrisAlt', min: 200, max: 40000, step: 10 },
            ].map(f => (
              <div key={f.key}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px' }}>{f.label.toUpperCase()}</label>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)' }}>{inputs[f.key]}</span>
                </div>
                <input type="range" className="range-slider" min={f.min} max={f.max} step={f.step} value={inputs[f.key]}
                  onChange={e => setInputs(p => ({ ...p, [f.key]: parseFloat(e.target.value) }))} />
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '2px' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'rgba(80,120,180,0.5)' }}>{f.min}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'rgba(80,120,180,0.5)' }}>{f.max}</span>
                </div>
              </div>
            ))}

            <button className="btn-primary" onClick={calculateCollision} style={{ marginTop: '8px', padding: '14px', fontSize: '13px' }} disabled={calculating}>
              {calculating ? '⟳ COMPUTING...' : '🤖 RUN AI PREDICTION'}
            </button>
          </div>
        </div>

        {/* Results */}
        <div>
          {calculating && (
            <div className="glass-card" style={{ padding: '24px' }}>
              <div className="loading-container" style={{ padding: '40px' }}>
                <div className="loading-spinner" />
                <div className="loading-text">COMPUTING TRAJECTORIES</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', textAlign: 'center', lineHeight: 1.8 }}>
                  Running orbital mechanics model...<br />
                  Applying Monte Carlo simulation...<br />
                  Calculating conjunction probability...
                </div>
              </div>
            </div>
          )}

          {prediction && !calculating && (
            <>
              {/* Probability Display */}
              <div className={`glass-card ${prediction.riskLevel === 'red' ? 'anim-pulse' : ''}`} style={{ padding: '24px', marginBottom: '16px', border: `1px solid ${prediction.riskLevel === 'red' ? 'rgba(255,34,68,0.6)' : prediction.riskLevel === 'orange' ? 'rgba(255,100,0,0.4)' : 'rgba(0,100,200,0.3)'}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: 'var(--text-secondary)', letterSpacing: '2px' }}>COLLISION PROBABILITY</div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '52px', fontWeight: 900, color: prediction.riskLevel === 'red' ? 'var(--accent-red)' : prediction.riskLevel === 'orange' ? 'var(--accent-orange)' : prediction.riskLevel === 'yellow' ? 'var(--accent-yellow)' : 'var(--accent-green)', textShadow: prediction.riskLevel === 'red' ? 'var(--glow-red)' : 'none', lineHeight: 1 }}>
                      {prediction.probability}%
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span className={`risk-badge ${prediction.riskLevel}`} style={{ fontSize: '14px', padding: '8px 16px' }}>
                      {prediction.riskLevel === 'red' ? '🔴 CRITICAL' : prediction.riskLevel === 'orange' ? '🟠 HIGH' : prediction.riskLevel === 'yellow' ? '🟡 MEDIUM' : '🟢 LOW'}
                    </span>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-dim)', marginTop: '8px' }}>TTE: {prediction.timeToEncounter}</div>
                  </div>
                </div>

                <div className="grid-2" style={{ gap: '10px', marginBottom: '16px' }}>
                  {[
                    { l: 'Relative Velocity', v: `${prediction.relativeVelocity} km/s` },
                    { l: 'Closest Approach', v: `${prediction.closestApproach} km` },
                    { l: 'Kinetic Energy', v: `${prediction.kineticEnergy} GJ` },
                    { l: 'Fragments if Impact', v: prediction.fragmentsIfImpact.toLocaleString() },
                  ].map(m => (
                    <div key={m.l} style={{ background: 'rgba(0,10,40,0.6)', borderRadius: '8px', padding: '10px' }}>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-dim)', letterSpacing: '1px' }}>{m.l.toUpperCase()}</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)', marginTop: '2px' }}>{m.v}</div>
                    </div>
                  ))}
                </div>

                <div style={{ background: 'rgba(128,0,255,0.05)', border: '1px solid rgba(128,0,255,0.3)', borderRadius: '8px', padding: '14px' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--accent-purple)', letterSpacing: '2px', marginBottom: '6px' }}>🤖 AI ASSESSMENT</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>{prediction.insight}</div>
                </div>
              </div>
            </>
          )}

          {/* Known conjunctions */}
          <div className="glass-card" style={{ padding: '20px' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '14px' }}>ACTIVE CONJUNCTION EVENTS</h3>
            {collisionPredictions.map(c => (
              <div key={c.id} style={{ marginBottom: '10px', padding: '12px', background: 'rgba(0,5,20,0.6)', borderRadius: '8px', borderLeft: `3px solid ${c.riskLevel === 'red' ? 'var(--accent-red)' : c.riskLevel === 'orange' ? 'var(--accent-orange)' : c.riskLevel === 'yellow' ? 'var(--accent-yellow)' : 'var(--accent-green)'}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'white' }}>{c.satellite}</span>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <span className={`risk-badge ${c.riskLevel}`}>{c.riskLevel.toUpperCase()}</span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '14px', fontWeight: 700, color: c.riskLevel === 'red' ? 'var(--accent-red)' : c.riskLevel === 'orange' ? 'var(--accent-orange)' : c.riskLevel === 'yellow' ? 'var(--accent-yellow)' : 'var(--accent-green)' }}>{c.probability}%</span>
                  </div>
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', marginBottom: '6px' }}>
                  {c.debris} · TTE: {c.timeToEncounter} · ΔV: {c.relativeVelocity} km/s
                </div>
                <div className="progress-bar-bg">
                  <div className="progress-bar-fill" style={{ width: `${c.probability}%`, background: c.riskLevel === 'red' ? 'var(--accent-red)' : c.riskLevel === 'orange' ? 'var(--accent-orange)' : c.riskLevel === 'yellow' ? 'var(--accent-yellow)' : 'var(--accent-green)' }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid-2" style={{ gap: '24px' }}>
        <div className="glass-card" style={{ padding: '20px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>CONJUNCTION PROBABILITY COMPARISON</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={probChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,100,200,0.1)" />
              <XAxis dataKey="name" tick={{ fill: '#7ab3d4', fontSize: 10, fontFamily: 'var(--font-mono)' }} />
              <YAxis tick={{ fill: '#7ab3d4', fontSize: 10, fontFamily: 'var(--font-mono)' }} unit="%" domain={[0, 40]} />
              <Tooltip contentStyle={{ background: 'rgba(0,10,40,0.95)', border: '1px solid rgba(0,245,255,0.3)', borderRadius: '8px', fontFamily: 'var(--font-mono)', fontSize: '12px', color: '#e0f4ff' }} />
              <Bar dataKey="probability" radius={[4, 4, 0, 0]}>
                {probChartData.map((entry, i) => (
                  <rect key={i} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-card" style={{ padding: '20px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>DEBRIS FIELD — ALT vs VELOCITY</h3>
          <ResponsiveContainer width="100%" height={220}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,100,200,0.1)" />
              <XAxis dataKey="x" name="Altitude" unit="km" tick={{ fill: '#7ab3d4', fontSize: 10, fontFamily: 'var(--font-mono)' }} />
              <YAxis dataKey="y" name="Velocity" unit=" km/s" tick={{ fill: '#7ab3d4', fontSize: 10, fontFamily: 'var(--font-mono)' }} />
              <ZAxis dataKey="z" range={[40, 300]} />
              <Tooltip contentStyle={{ background: 'rgba(0,10,40,0.95)', border: '1px solid rgba(0,245,255,0.3)', borderRadius: '8px', fontFamily: 'var(--font-mono)', fontSize: '12px', color: '#e0f4ff' }} cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData} fill="#ff2244" fillOpacity={0.7} />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
