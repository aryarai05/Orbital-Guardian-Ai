import React, { useState, useEffect } from 'react';
import { dashboardStats, collisionPredictions, debrisData, spaceWeatherData } from '../../data/spaceData';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis } from 'recharts';

export default function Dashboard({ onNavigate }) {
  const [counters, setCounters] = useState({ activeSatellites: 0, trackedDebris: 0, potentialThreats: 0, collisionPredictions: 0 });
  const [currentTime, setCurrentTime] = useState(new Date());
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const targets = dashboardStats;
    const duration = 2000;
    const steps = 60;
    const interval = duration / steps;
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const ease = 1 - Math.pow(1 - progress, 3);
      setCounters({
        activeSatellites: Math.floor(targets.activeSatellites * ease),
        trackedDebris: Math.floor(targets.trackedDebris * ease),
        potentialThreats: Math.floor(targets.potentialThreats * ease),
        collisionPredictions: Math.floor(targets.collisionPredictions * ease),
      });
      if (step >= steps) clearInterval(timer);
    }, interval);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const initialAlerts = [
      { id: 1, time: '14:23:07', type: 'critical', msg: 'CRITICAL: Sentinel-2A conjunction with Object Zeta-1 — 31.5% collision probability' },
      { id: 2, time: '13:47:22', type: 'warning', msg: 'WARNING: ISS debris Alpha-7 approach window in 47h 23m' },
      { id: 3, time: '13:12:55', type: 'info', msg: 'INFO: 3 new debris fragments catalogued from Fengyun-1C field' },
      { id: 4, time: '12:58:31', type: 'info', msg: 'INFO: Space weather: Kp-index elevated to 4.2 — minor geomagnetic activity' },
    ];
    setAlerts(initialAlerts);
  }, []);

  const riskData = [
    { subject: 'LEO', A: 85, fullMark: 100 },
    { subject: 'MEO', A: 42, fullMark: 100 },
    { subject: 'GEO', A: 23, fullMark: 100 },
    { subject: 'HEO', A: 15, fullMark: 100 },
    { subject: 'SSO', A: 67, fullMark: 100 },
    { subject: 'GTO', A: 38, fullMark: 100 },
  ];

  return (
    <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 className="section-title" style={{ fontSize: '20px' }}>📡 MISSION CONTROL CENTER</h1>
          <p className="section-sub">Real-time orbital monitoring and threat assessment</p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '18px', color: 'var(--accent-cyan)' }}>
            {currentTime.toISOString().replace('T', ' ').slice(0, 19)} UTC
          </div>
          <div style={{ display: 'flex', gap: '8px', marginTop: '4px', justifyContent: 'flex-end' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-green)' }}><span className="anim-blink">●</span> SYSTEMS NOMINAL</span>
          </div>
        </div>
      </div>

      {/* Main stats */}
      <div className="grid-4" style={{ marginBottom: '24px' }}>
        {[
          { value: counters.activeSatellites.toLocaleString(), label: 'Active Satellites', icon: '🛸', color: 'var(--accent-cyan)', sub: '+12 today' },
          { value: counters.trackedDebris.toLocaleString(), label: 'Tracked Debris', icon: '⚠️', color: '#ff8800', sub: '+47 this week' },
          { value: counters.potentialThreats, label: 'Potential Threats', icon: '🎯', color: 'var(--accent-red)', sub: '4 critical' },
          { value: counters.collisionPredictions, label: 'Conjunction Events', icon: '💥', color: 'var(--accent-yellow)', sub: 'Next 72h' },
        ].map((stat, i) => (
          <div key={i} className="metric-card hologram" style={{ cursor: 'pointer' }} onClick={() => i === 1 ? onNavigate('debris') : i >= 2 ? onNavigate('collision') : null}>
            <div style={{ fontSize: '28px', marginBottom: '8px' }}>{stat.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '26px', fontWeight: 700, color: stat.color }}>{stat.value}</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '1px', marginTop: '4px' }}>{stat.label}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: stat.color, marginTop: '4px', opacity: 0.7 }}>{stat.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid-2" style={{ marginBottom: '24px' }}>
        {/* Space Weather Chart */}
        <div className="glass-card" style={{ padding: '20px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>SPACE WEATHER — KP INDEX TREND</h3>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={spaceWeatherData}>
              <defs>
                <linearGradient id="kpGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00f5ff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#00f5ff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,100,200,0.15)" />
              <XAxis dataKey="date" tick={{ fill: '#7ab3d4', fontSize: 11, fontFamily: 'var(--font-mono)' }} />
              <YAxis tick={{ fill: '#7ab3d4', fontSize: 11, fontFamily: 'var(--font-mono)' }} domain={[0, 9]} />
              <Tooltip contentStyle={{ background: 'rgba(0,10,40,0.95)', border: '1px solid rgba(0,245,255,0.3)', borderRadius: '8px', fontFamily: 'var(--font-mono)', fontSize: '12px', color: '#e0f4ff' }} />
              <Area type="monotone" dataKey="kpIndex" stroke="#00f5ff" fill="url(#kpGrad)" strokeWidth={2} dot={{ fill: '#00f5ff', r: 4 }} />
            </AreaChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', gap: '16px', marginTop: '12px', flexWrap: 'wrap' }}>
            {['Quiet (0-3)', 'Active (4-5)', 'Storm (6+)'].map((l, i) => (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: ['var(--accent-green)', 'var(--accent-yellow)', 'var(--accent-red)'][i] }} />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)' }}>{l}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Radar Chart */}
        <div className="glass-card" style={{ padding: '20px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>ORBITAL RISK MAP — BY ZONE</h3>
          <ResponsiveContainer width="100%" height={180}>
            <RadarChart data={riskData}>
              <PolarGrid stroke="rgba(0,100,200,0.2)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#7ab3d4', fontSize: 11, fontFamily: 'var(--font-mono)' }} />
              <Radar name="Risk" dataKey="A" stroke="#ff2244" fill="#ff2244" fillOpacity={0.15} strokeWidth={2} dot={{ fill: '#ff2244', r: 3 }} />
              <Tooltip contentStyle={{ background: 'rgba(0,10,40,0.95)', border: '1px solid rgba(255,34,68,0.3)', borderRadius: '8px', fontFamily: 'var(--font-mono)', fontSize: '12px', color: '#e0f4ff' }} />
            </RadarChart>
          </ResponsiveContainer>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', marginTop: '8px', textAlign: 'center' }}>
            LEO = Low Earth Orbit | SSO = Sun-Synchronous
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid-2" style={{ marginBottom: '24px' }}>
        {/* Critical Conjunctions */}
        <div className="glass-card" style={{ padding: '20px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>CRITICAL CONJUNCTION EVENTS</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {collisionPredictions.map(c => (
              <div key={c.id} style={{ background: 'rgba(0,10,40,0.6)', borderRadius: '8px', padding: '12px', border: `1px solid ${c.riskLevel === 'red' ? 'rgba(255,34,68,0.3)' : c.riskLevel === 'orange' ? 'rgba(255,100,0,0.3)' : 'rgba(0,100,200,0.2)'}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: 'white', letterSpacing: '1px' }}>{c.satellite}</span>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <span className={`risk-badge ${c.riskLevel}`}>{c.riskLevel.toUpperCase()}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '16px', fontWeight: 700, color: c.riskLevel === 'red' ? 'var(--accent-red)' : c.riskLevel === 'orange' ? 'var(--accent-orange)' : c.riskLevel === 'yellow' ? 'var(--accent-yellow)' : 'var(--accent-green)' }}>{c.probability}%</span>
                  </div>
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)' }}>vs {c.debris} · TTE: {c.timeToEncounter}</div>
                <div style={{ marginTop: '6px' }}>
                  <div className="progress-bar-bg">
                    <div className="progress-bar-fill" style={{ width: `${c.probability}%`, background: c.riskLevel === 'red' ? 'var(--accent-red)' : c.riskLevel === 'orange' ? 'var(--accent-orange)' : c.riskLevel === 'yellow' ? 'var(--accent-yellow)' : 'var(--accent-green)' }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="btn-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => onNavigate('collision')}>
            FULL COLLISION ANALYSIS →
          </button>
        </div>

        {/* Alert Feed */}
        <div className="glass-card" style={{ padding: '20px' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>
            <span className="anim-blink" style={{ color: 'var(--accent-red)', marginRight: '8px' }}>●</span>
            LIVE ALERT FEED
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {alerts.map(a => (
              <div key={a.id} style={{ background: 'rgba(0,5,20,0.8)', borderRadius: '6px', padding: '10px 12px', borderLeft: `3px solid ${a.type === 'critical' ? 'var(--accent-red)' : a.type === 'warning' ? 'var(--accent-yellow)' : 'var(--accent-blue)'}` }}>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', whiteSpace: 'nowrap' }}>{a.time}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: a.type === 'critical' ? 'var(--accent-red)' : a.type === 'warning' ? 'var(--accent-yellow)' : 'var(--text-secondary)', lineHeight: 1.4 }}>{a.msg}</span>
                </div>
              </div>
            ))}
          </div>

          {/* AI Insight */}
          <div style={{ marginTop: '16px', background: 'rgba(128,0,255,0.05)', border: '1px solid rgba(128,0,255,0.3)', borderRadius: '8px', padding: '14px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--accent-purple)', letterSpacing: '2px', marginBottom: '6px' }}>🤖 AI INSIGHT</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              "Debris cluster activity elevated by 23% in LEO corridor 400-450km. Recommend issuing advisory notice to active satellite operators. Probability of Kessler cascade initiation: 0.003% over 30-day window."
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="glass-card" style={{ padding: '20px' }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>QUICK ACCESS MODULES</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '12px' }}>
          {[
            { label: 'Solar System', icon: '🌌', view: 'solar-system', color: 'var(--accent-blue)' },
            { label: 'Debris Detection', icon: '🎯', view: 'debris', color: 'var(--accent-orange)' },
            { label: 'Collision AI', icon: '⚡', view: 'collision', color: 'var(--accent-red)' },
            { label: 'Orbit Simulation', icon: '🛸', view: 'orbit', color: 'var(--accent-cyan)' },
            { label: 'Space Academy', icon: '📚', view: 'education', color: 'var(--accent-purple)' },
            { label: 'Why It Matters', icon: '⚠️', view: 'why-matters', color: 'var(--accent-yellow)' },
          ].map(m => (
            <button key={m.view} onClick={() => onNavigate(m.view)} style={{ background: 'rgba(0,10,40,0.6)', border: `1px solid rgba(0,100,200,0.2)`, borderRadius: '10px', padding: '16px', cursor: 'pointer', textAlign: 'center', transition: 'all 0.3s', color: 'inherit' }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = m.color; e.currentTarget.style.background = 'rgba(0,20,60,0.8)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(0,100,200,0.2)'; e.currentTarget.style.background = 'rgba(0,10,40,0.6)'; }}>
              <div style={{ fontSize: '24px', marginBottom: '6px' }}>{m.icon}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: m.color, letterSpacing: '1px' }}>{m.label}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
