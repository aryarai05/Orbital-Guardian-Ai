import React, { useState } from 'react';

export default function WhyItMatters() {
  const [activeSection, setActiveSection] = useState('kessler');

  const sections = [
    { id: 'kessler', label: 'Kessler Syndrome', icon: '⚠️' },
    { id: 'architecture', label: 'AI Architecture', icon: '🤖' },
    { id: 'ml-workflow', label: 'ML Workflow', icon: '⚙️' },
    { id: 'metrics', label: 'Performance Metrics', icon: '📊' },
    { id: 'data', label: 'Data Sources', icon: '🗄️' },
  ];

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ marginBottom: '28px' }}>
        <div style={{ fontSize: '36px', marginBottom: '8px' }}>⚠️</div>
        <h1 className="section-title">WHY THIS PROJECT MATTERS</h1>
        <p className="section-sub">Space sustainability · AI for planetary protection · The Kessler threat</p>
      </div>

      {/* Tab nav */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '28px', flexWrap: 'wrap' }}>
        {sections.map(s => (
          <button key={s.id} onClick={() => setActiveSection(s.id)}
            style={{ background: activeSection === s.id ? 'rgba(0,245,255,0.1)' : 'rgba(0,10,40,0.5)', border: `1px solid ${activeSection === s.id ? 'var(--accent-cyan)' : 'rgba(0,100,180,0.3)'}`, borderRadius: '6px', padding: '8px 16px', color: activeSection === s.id ? 'var(--accent-cyan)' : 'var(--text-secondary)', fontFamily: 'var(--font-display)', fontSize: '10px', letterSpacing: '2px', cursor: 'pointer', transition: 'all 0.2s', textTransform: 'uppercase' }}>
            {s.icon} {s.label}
          </button>
        ))}
      </div>

      {/* Kessler Syndrome */}
      {activeSection === 'kessler' && (
        <div>
          <div className="glass-card" style={{ padding: '28px', marginBottom: '20px', borderColor: 'rgba(255,34,68,0.3)' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'var(--accent-red)', letterSpacing: '3px', marginBottom: '16px' }}>
              ☠️ THE KESSLER SYNDROME
            </h2>
            <p style={{ fontFamily: 'var(--font-body)', fontSize: '16px', color: 'var(--text-primary)', lineHeight: 1.8, marginBottom: '20px' }}>
              Proposed by NASA scientist Donald Kessler in 1978, the Kessler Syndrome describes a catastrophic
              self-sustaining cascade of collisions in low Earth orbit. Once debris density reaches a critical
              threshold, each collision generates more debris, which causes more collisions — an unstoppable
              chain reaction that could render entire orbital bands permanently unusable.
            </p>
            <div className="grid-2" style={{ gap: '16px', marginBottom: '20px' }}>
              {[
                { title: 'The Trigger', content: 'A single collision between two sizable objects can generate thousands of fragments, each capable of destroying another satellite.', icon: '💥', color: 'var(--accent-red)' },
                { title: 'The Cascade', content: 'Each new fragment increases collision probability for remaining satellites, triggering more collisions in an exponential chain reaction.', icon: '⛓️', color: '#ff8800' },
                { title: 'The Consequence', content: 'Critical orbital altitudes become impassable — no GPS, weather satellites, communications networks, or ISS resupply missions.', icon: '🌍', color: 'var(--accent-yellow)' },
                { title: 'The Timeline', content: 'Some models predict certain LEO corridors could become unusable within 20-40 years without active debris removal measures.', icon: '⏱️', color: 'var(--accent-cyan)' },
              ].map(c => (
                <div key={c.title} style={{ background: 'rgba(0,10,40,0.6)', borderRadius: '10px', padding: '18px', borderLeft: `3px solid ${c.color}` }}>
                  <div style={{ fontSize: '24px', marginBottom: '8px' }}>{c.icon}</div>
                  <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: c.color, letterSpacing: '1px', marginBottom: '8px' }}>{c.title.toUpperCase()}</h4>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{c.content}</p>
                </div>
              ))}
            </div>

            {/* Real stats */}
            <div style={{ background: 'rgba(255,34,68,0.05)', border: '1px solid rgba(255,34,68,0.2)', borderRadius: '10px', padding: '20px' }}>
              <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-red)', letterSpacing: '2px', marginBottom: '14px' }}>CURRENT THREAT STATISTICS</h4>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '12px' }}>
                {[
                  { v: '27,852', l: 'Trackable debris objects (>10cm)' },
                  { v: '500,000+', l: 'Marble-sized fragments (>1cm)' },
                  { v: '100M+', l: 'Tiny particles (>1mm)' },
                  { v: '~29,000', l: 'km/h average debris speed' },
                  { v: '2009', l: 'Iridium-Cosmos first major collision' },
                  { v: '3,000+', l: 'Fragments from 2021 Russian ASAT test' },
                ].map(s => (
                  <div key={s.l} style={{ textAlign: 'center', padding: '12px', background: 'rgba(0,5,20,0.5)', borderRadius: '8px' }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--accent-red)', fontWeight: 700 }}>{s.v}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-dim)', letterSpacing: '1px', marginTop: '4px', lineHeight: 1.4 }}>{s.l.toUpperCase()}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Why AI */}
          <div className="glass-card" style={{ padding: '24px' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '16px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '16px' }}>WHY AI IS THE SOLUTION</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '14px' }}>
              {[
                { icon: '⚡', title: 'Real-Time Processing', desc: 'Traditional methods take hours to compute conjunction analyses. AI can process thousands of object trajectories in milliseconds.' },
                { icon: '🎯', title: 'Pattern Recognition', desc: 'ML models detect anomalous debris behavior, potential fragmentation events, and cluster formation patterns invisible to rule-based systems.' },
                { icon: '📡', title: 'Sensor Fusion', desc: 'AI integrates radar, optical, and TLE data from multiple sources to build a more accurate and complete orbital picture.' },
                { icon: '🔮', title: 'Predictive Capability', desc: 'Deep learning models can predict likely collision events 72+ hours in advance, giving operators time to plan avoidance maneuvers.' },
              ].map(c => (
                <div key={c.title} style={{ padding: '16px', background: 'rgba(0,15,50,0.5)', borderRadius: '8px', border: '1px solid rgba(0,100,180,0.2)' }}>
                  <div style={{ fontSize: '28px', marginBottom: '8px' }}>{c.icon}</div>
                  <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)', letterSpacing: '1px', marginBottom: '6px' }}>{c.title}</h4>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{c.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* AI Architecture */}
      {activeSection === 'architecture' && (
        <div>
          <div className="glass-card" style={{ padding: '28px', marginBottom: '20px' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '20px' }}>
              🤖 ORBITAL GUARDIAN AI ARCHITECTURE
            </h2>

            {/* Architecture diagram using divs */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px', background: 'rgba(0,5,20,0.6)', borderRadius: '12px', marginBottom: '24px' }}>
              {/* Layer 1 - Data Input */}
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '2px', marginBottom: '8px' }}>DATA INGESTION LAYER</div>
                <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
                  {['Satellite TLE Data', 'Radar Observations', 'Optical Imagery', 'Space Weather', 'Historical Conjunctions'].map(s => (
                    <div key={s} style={{ padding: '6px 12px', background: 'rgba(0,128,255,0.15)', border: '1px solid rgba(0,128,255,0.4)', borderRadius: '6px', fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-blue)', letterSpacing: '1px' }}>{s}</div>
                  ))}
                </div>
              </div>
              <div style={{ textAlign: 'center', color: 'var(--accent-cyan)', fontSize: '18px' }}>↓</div>

              {/* Layer 2 - Processing */}
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '2px', marginBottom: '8px' }}>AI PROCESSING LAYER</div>
                <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
                  {['YOLOv8 Detection', 'LSTM Trajectory Prediction', 'Random Forest Classifier', 'Physics Simulation Engine', 'Monte Carlo Probability'].map(s => (
                    <div key={s} style={{ padding: '6px 12px', background: 'rgba(128,0,255,0.15)', border: '1px solid rgba(128,0,255,0.4)', borderRadius: '6px', fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-purple)', letterSpacing: '1px' }}>{s}</div>
                  ))}
                </div>
              </div>
              <div style={{ textAlign: 'center', color: 'var(--accent-cyan)', fontSize: '18px' }}>↓</div>

              {/* Layer 3 - Output */}
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '2px', marginBottom: '8px' }}>OUTPUT & VISUALIZATION LAYER</div>
                <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
                  {['3D Orbit Visualization', 'Collision Alerts', 'Risk Dashboard', 'AI Insights', 'Voice Narration'].map(s => (
                    <div key={s} style={{ padding: '6px 12px', background: 'rgba(0,245,255,0.1)', border: '1px solid rgba(0,245,255,0.3)', borderRadius: '6px', fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-cyan)', letterSpacing: '1px' }}>{s}</div>
                  ))}
                </div>
              </div>
            </div>

            {/* Tech Stack */}
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '14px' }}>TECHNOLOGY STACK</h3>
            <div className="grid-2" style={{ gap: '16px' }}>
              {[
                { category: 'Frontend', color: 'var(--accent-cyan)', items: ['React 18 + TypeScript', 'Three.js + React Three Fiber', 'Framer Motion', 'Tailwind CSS', 'Recharts / Plotly', 'Web Speech API'] },
                { category: 'Backend & ML', color: 'var(--accent-purple)', items: ['FastAPI (Python)', 'YOLOv8 (Ultralytics)', 'TensorFlow / Keras', 'Scikit-learn', 'NumPy / SciPy', 'Astropy / Poliastro'] },
                { category: 'Data & Storage', color: '#ff8800', items: ['PostgreSQL', 'CelesTrak TLE API', 'NASA Open APIs', 'ESA Space Debris Office', 'NOAA Space Weather', 'Space-Track.org'] },
                { category: 'DevOps', color: 'var(--accent-green)', items: ['Docker + Docker Compose', 'Vercel (Frontend)', 'Render (Backend)', 'GitHub Actions CI/CD', 'Prometheus Monitoring', 'Redis Caching'] },
              ].map(cat => (
                <div key={cat.category} style={{ background: 'rgba(0,10,40,0.6)', borderRadius: '8px', padding: '16px' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '11px', color: cat.color, letterSpacing: '2px', marginBottom: '10px' }}>{cat.category.toUpperCase()}</div>
                  {cat.items.map(item => (
                    <div key={item} style={{ display: 'flex', gap: '8px', marginBottom: '5px', alignItems: 'center' }}>
                      <span style={{ color: cat.color, fontSize: '10px', flexShrink: 0 }}>›</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-secondary)' }}>{item}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ML Workflow */}
      {activeSection === 'ml-workflow' && (
        <div>
          <div className="glass-card" style={{ padding: '28px', marginBottom: '20px' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '20px' }}>⚙️ ML PIPELINE WORKFLOW</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {[
                { step: '01', title: 'Data Collection & Preprocessing', color: 'var(--accent-blue)', desc: 'Raw TLE data from CelesTrak and Space-Track.org is ingested every 4 hours. Orbital elements are parsed and validated. Historical conjunction events from ESA\'s DISCOS database are used for training labels. Images from satellite cameras are preprocessed with contrast enhancement and noise reduction.', tech: ['Astropy', 'Pandas', 'OpenCV', 'NumPy'] },
                { step: '02', title: 'Feature Engineering', color: 'var(--accent-cyan)', desc: 'Orbital parameters are transformed into ML-ready features: relative velocity, minimum orbit intersection distance (MOID), conjunction geometry angle, space weather indices (Kp, F10.7), and object size estimates. Time-series features capture trajectory evolution over 24-hour windows.', tech: ['Scikit-learn', 'Poliastro', 'SciPy'] },
                { step: '03', title: 'Model Training — Debris Detection', color: 'var(--accent-purple)', desc: 'YOLOv8 is fine-tuned on a custom dataset of 50,000+ satellite images with labeled debris bounding boxes. Transfer learning from pretrained COCO weights accelerates convergence. Data augmentation includes rotation, blur, and brightness variation to simulate different orbital lighting conditions.', tech: ['YOLOv8', 'Ultralytics', 'PyTorch', 'CUDA'] },
                { step: '04', title: 'Model Training — Collision Prediction', color: '#ff8800', desc: 'A gradient-boosted ensemble (XGBoost + Random Forest) classifies conjunction risk levels. An LSTM network predicts 72-hour trajectory evolution. Monte Carlo simulation runs 10,000 iterations per conjunction to compute probability distributions. Calibrated probability outputs using Platt scaling.', tech: ['XGBoost', 'TensorFlow', 'Keras', 'scikit-learn'] },
                { step: '05', title: 'Model Evaluation & Validation', color: 'var(--accent-yellow)', desc: 'Models are evaluated against the ESA/NASA historical conjunction database. Key metrics: F1 score for risk classification, MAE for trajectory prediction, and mAP for debris detection. A/B testing compares new model versions before deployment. False negative rate is prioritized over false positive rate for safety-critical decisions.', tech: ['MLflow', 'Weights & Biases', 'pytest'] },
                { step: '06', title: 'Deployment & Monitoring', color: 'var(--accent-green)', desc: 'Models are containerized with Docker and deployed via FastAPI endpoints. Real-time monitoring tracks prediction confidence drift and data distribution shifts. Automated retraining triggers when model performance degrades below threshold. All predictions are logged for audit and continuous improvement.', tech: ['FastAPI', 'Docker', 'Prometheus', 'MLflow'] },
              ].map(step => (
                <div key={step.step} style={{ display: 'flex', gap: '20px', padding: '18px', background: 'rgba(0,10,40,0.5)', borderRadius: '10px', borderLeft: `3px solid ${step.color}`, alignItems: 'flex-start' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '28px', color: step.color, opacity: 0.4, minWidth: '40px', flexShrink: 0 }}>{step.step}</div>
                  <div style={{ flex: 1 }}>
                    <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: step.color, letterSpacing: '1px', marginBottom: '8px' }}>{step.title.toUpperCase()}</h4>
                    <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '10px' }}>{step.desc}</p>
                    <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                      {step.tech.map(t => <span key={t} className="tag">{t}</span>)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Performance Metrics */}
      {activeSection === 'metrics' && (
        <div>
          <div className="grid-2" style={{ gap: '20px', marginBottom: '20px' }}>
            {[
              { title: 'Debris Detection (YOLOv8)', color: 'var(--accent-cyan)', metrics: [{ l: 'mAP@0.5', v: '94.7%' }, { l: 'Precision', v: '93.2%' }, { l: 'Recall', v: '91.8%' }, { l: 'F1 Score', v: '92.5%' }, { l: 'Inference Time', v: '12ms' }, { l: 'Training Dataset', v: '50,000 images' }] },
              { title: 'Collision Prediction (Ensemble)', color: 'var(--accent-purple)', metrics: [{ l: 'Accuracy', v: '97.3%' }, { l: 'F1 Score (Critical)', v: '95.1%' }, { l: 'AUC-ROC', v: '0.987' }, { l: 'False Negative Rate', v: '0.8%' }, { l: 'Avg Prediction Horizon', v: '72 hours' }, { l: 'Training Samples', v: '2.4M events' }] },
              { title: 'Trajectory Prediction (LSTM)', color: '#ff8800', metrics: [{ l: 'Position Error (24h)', v: '±127m' }, { l: 'Position Error (72h)', v: '±892m' }, { l: 'Velocity MAE', v: '0.003 km/s' }, { l: 'RMSE (Altitude)', v: '45m' }, { l: 'Sequence Length', v: '144 steps' }, { l: 'Validation Loss', v: '0.0018' }] },
              { title: 'System Performance', color: 'var(--accent-green)', metrics: [{ l: 'API Response Time', v: '<200ms' }, { l: 'Throughput', v: '10,000 req/min' }, { l: 'Uptime', v: '99.97%' }, { l: 'Objects Tracked', v: '27,852' }, { l: 'Update Frequency', v: '15 minutes' }, { l: 'Alert Latency', v: '<5 seconds' }] },
            ].map(cat => (
              <div key={cat.title} className="glass-card" style={{ padding: '22px' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: cat.color, letterSpacing: '2px', marginBottom: '16px' }}>{cat.title.toUpperCase()}</h3>
                {cat.metrics.map(m => (
                  <div key={m.l} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid rgba(0,60,120,0.2)' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-dim)' }}>{m.l}</span>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '13px', color: cat.color, fontWeight: 600 }}>{m.v}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Data Sources */}
      {activeSection === 'data' && (
        <div>
          <div className="glass-card" style={{ padding: '28px', marginBottom: '20px' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '8px' }}>🗄️ DATA SOURCES & DATASETS</h2>
            <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'var(--text-secondary)', marginBottom: '24px', lineHeight: 1.6 }}>
              Orbital Guardian AI relies on authoritative, publicly available space surveillance data from the world's leading space agencies and research institutions.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {[
                { org: 'NASA', logo: '🚀', color: '#0b3d91', desc: 'Primary source for asteroid close-approach data, space weather parameters, and historical mission data. NASA Open APIs provide near-real-time orbital elements and planetary science data.', datasets: ['Near Earth Object Close Approaches', 'NASA Image Library', 'DONKI Space Weather Events', 'Exoplanet Archive'], url: 'data.nasa.gov' },
                { org: 'European Space Agency (ESA)', logo: '🇪🇺', color: '#003087', desc: 'ESA\'s Space Debris Office provides the most comprehensive debris environment models. DISCOS (Database and Information System Characterising Objects in Space) tracks all catalogued objects.', datasets: ['DISCOS Debris Catalogue', 'Space Debris Environment Report', 'MASTER-8 Model', 'Re-entry Predictions'], url: 'sdup.esoc.esa.int' },
                { org: 'CelesTrak', logo: '🛰️', color: '#1a1a4e', desc: 'The go-to source for TLE (Two-Line Element) data used to compute satellite and debris orbital positions. Provides real-time updates and historical archives.', datasets: ['Active Satellites TLE', 'Starlink Constellation', 'ISS TLE', 'Full Debris Catalogue'], url: 'celestrak.org' },
                { org: 'NOAA Space Weather Prediction Center', logo: '🌤️', color: '#007a33', desc: 'Provides solar activity data crucial for atmospheric drag modeling. High solar activity expands Earth\'s atmosphere, increasing drag on low-orbit objects and affecting predictions.', datasets: ['Kp Index (Geomagnetic Activity)', 'Solar Flux (F10.7)', 'Solar Flare Events', 'Geomagnetic Storm Alerts'], url: 'swpc.noaa.gov' },
                { org: 'Space-Track.org (18th Space Defense Squadron)', logo: '⭐', color: '#1c2951', desc: 'Official US military space surveillance catalog. Provides the most authoritative and up-to-date tracking data for all catalogued Earth-orbiting objects.', datasets: ['Space Object Catalog', 'Conjunction Data Messages (CDM)', 'Decay Predictions', 'Launch Events'], url: 'space-track.org' },
              ].map(src => (
                <div key={src.org} style={{ padding: '20px', background: 'rgba(0,10,40,0.6)', borderRadius: '10px', border: '1px solid rgba(0,100,180,0.2)', display: 'flex', gap: '18px', alignItems: 'flex-start', flexWrap: 'wrap' }}>
                  <div style={{ fontSize: '40px', flexShrink: 0 }}>{src.logo}</div>
                  <div style={{ flex: 1, minWidth: '200px' }}>
                    <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '8px', flexWrap: 'wrap' }}>
                      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)', letterSpacing: '1px' }}>{src.org}</h3>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-blue)', background: 'rgba(0,128,255,0.1)', padding: '2px 8px', borderRadius: '4px', border: '1px solid rgba(0,128,255,0.3)' }}>{src.url}</span>
                    </div>
                    <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '10px' }}>{src.desc}</p>
                    <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                      {src.datasets.map(d => <span key={d} style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', padding: '3px 8px', background: 'rgba(0,20,60,0.8)', border: '1px solid rgba(0,100,200,0.3)', borderRadius: '4px', color: 'var(--text-secondary)' }}>{d}</span>)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
