import React, { useState } from 'react';
import { educationTopics } from '../../data/spaceData';

const spaceMissions = [
  { name: 'Apollo 11', year: 1969, agency: 'NASA', desc: 'First crewed lunar landing. Neil Armstrong became the first human to walk on the Moon on July 20, 1969.', icon: '🌙' },
  { name: 'Voyager 1', year: 1977, agency: 'NASA', desc: 'Farthest human-made object. Now in interstellar space, over 23 billion km from the Sun.', icon: '🚀' },
  { name: 'Hubble Space Telescope', year: 1990, agency: 'NASA/ESA', desc: 'Revolutionized astronomy. Has made over 1.5 million observations and helped determine the age of the universe.', icon: '🔭' },
  { name: 'Mars Curiosity', year: 2012, agency: 'NASA', desc: 'Car-sized rover exploring Mars\'s Gale Crater, searching for signs of ancient habitability.', icon: '🤖' },
  { name: 'James Webb Space Telescope', year: 2021, agency: 'NASA/ESA/CSA', desc: 'Most powerful space telescope ever built. Observes the universe in infrared, seeing the first galaxies.', icon: '🌌' },
  { name: 'Artemis Program', year: 2024, agency: 'NASA', desc: 'Return humans to the Moon and establish sustainable lunar presence as gateway to Mars.', icon: '👩‍🚀' },
];

const rocketScience = [
  { title: 'Tsiolkovsky Rocket Equation', formula: 'Δv = ve × ln(m₀/mf)', desc: 'Fundamental equation relating rocket speed, exhaust velocity, and mass ratio. The cornerstone of all rocket design.' },
  { title: 'Orbital Velocity', formula: 'v = √(GM/r)', desc: 'The speed required to maintain a circular orbit at a given radius from a planet\'s center. For LEO: ~7.8 km/s.' },
  { title: 'Escape Velocity', formula: 'v_esc = √(2GM/r)', desc: 'Minimum speed needed to escape a planet\'s gravitational pull without additional propulsion. Earth: 11.2 km/s.' },
  { title: 'Hohmann Transfer', formula: 'Δv = √(μ/r₁)(√(2r₂/(r₁+r₂)) - 1)', desc: 'Most fuel-efficient method to transfer between two circular orbits using two engine burns.' },
];

export default function EducationCenter() {
  const [activeTopic, setActiveTopic] = useState(null);
  const [activeTab, setActiveTab] = useState('topics');

  const speak = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.85; u.pitch = 0.7; u.volume = 0.8;
      window.speechSynthesis.speak(u);
    }
  };

  const tabs = [
    { id: 'topics', label: 'Space Topics' },
    { id: 'missions', label: 'Space Missions' },
    { id: 'rockets', label: 'Rocket Science' },
    { id: 'satellites', label: 'Satellites 101' },
  ];

  return (
    <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
      <div style={{ marginBottom: '28px' }}>
        <div style={{ fontSize: '36px', marginBottom: '8px' }}>📚</div>
        <h1 className="section-title">SPACE ACADEMY</h1>
        <p className="section-sub">Interactive space education · Voice-narrated lessons · Explore the cosmos</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '4px', marginBottom: '28px', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{ background: activeTab === t.id ? 'rgba(0,245,255,0.08)' : 'transparent', border: 'none', borderBottom: activeTab === t.id ? '2px solid var(--accent-cyan)' : '2px solid transparent', color: activeTab === t.id ? 'var(--accent-cyan)' : 'var(--text-secondary)', fontFamily: 'var(--font-display)', fontSize: '11px', letterSpacing: '2px', textTransform: 'uppercase', padding: '10px 20px', cursor: 'pointer', marginBottom: '-1px', transition: 'all 0.2s' }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Topics Tab */}
      {activeTab === 'topics' && (
        <div>
          {!activeTopic ? (
            <div className="grid-2" style={{ gap: '20px' }}>
              {educationTopics.map(topic => (
                <div key={topic.id} className="glass-card" style={{ padding: '24px', cursor: 'pointer', transition: 'all 0.3s' }}
                  onClick={() => setActiveTopic(topic)}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(0,245,255,0.4)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(0,100,180,0.3)'; e.currentTarget.style.transform = 'none'; }}>
                  <div style={{ fontSize: '40px', marginBottom: '12px' }}>{topic.icon}</div>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '16px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '10px' }}>{topic.title.toUpperCase()}</h3>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '14px' }}>{topic.description}</p>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '10px' }}>EXPLORE →</button>
                    <button className="btn-primary" style={{ padding: '6px 14px', fontSize: '10px', borderColor: 'var(--accent-purple)', color: 'var(--accent-purple)' }} onClick={e => { e.stopPropagation(); speak(topic.voiceText); }}>🔊 LISTEN</button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div>
              <button onClick={() => setActiveTopic(null)} style={{ background: 'none', border: '1px solid var(--border-subtle)', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', fontSize: '11px', padding: '6px 14px', borderRadius: '4px', cursor: 'pointer', marginBottom: '20px', letterSpacing: '1px' }}>
                ← BACK TO TOPICS
              </button>
              <div className="glass-card" style={{ padding: '28px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
                  <div>
                    <div style={{ fontSize: '48px', marginBottom: '8px' }}>{activeTopic.icon}</div>
                    <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '22px', color: 'var(--accent-cyan)', letterSpacing: '3px' }}>{activeTopic.title.toUpperCase()}</h2>
                  </div>
                  <button className="btn-primary" style={{ padding: '10px 20px' }} onClick={() => speak(activeTopic.voiceText)}>🔊 VOICE NARRATION</button>
                </div>
                <p style={{ fontFamily: 'var(--font-body)', fontSize: '16px', color: 'var(--text-primary)', lineHeight: 1.8, marginBottom: '24px' }}>{activeTopic.content}</p>
                <div style={{ background: 'rgba(0,10,40,0.6)', borderRadius: '10px', padding: '20px', marginBottom: '20px' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)', letterSpacing: '2px', marginBottom: '14px' }}>KEY FACTS</div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '10px' }}>
                    {activeTopic.facts.map((fact, i) => (
                      <div key={i} style={{ display: 'flex', gap: '10px', padding: '10px', background: 'rgba(0,20,60,0.5)', borderRadius: '6px', borderLeft: '2px solid var(--accent-cyan)' }}>
                        <span style={{ color: 'var(--accent-cyan)', fontSize: '14px', flexShrink: 0 }}>0{i + 1}</span>
                        <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.4 }}>{fact}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Missions Tab */}
      {activeTab === 'missions' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {spaceMissions.map((mission, i) => (
            <div key={mission.name} className="glass-card" style={{ padding: '20px', display: 'flex', gap: '20px', alignItems: 'center', flexWrap: 'wrap' }}>
              <div style={{ fontSize: '40px', flexShrink: 0 }}>{mission.icon}</div>
              <div style={{ flex: 1, minWidth: '200px' }}>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '6px', flexWrap: 'wrap' }}>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '16px', color: 'var(--accent-cyan)', letterSpacing: '1px' }}>{mission.name}</h3>
                  <span className="tag">{mission.agency}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-dim)' }}>{mission.year}</span>
                </div>
                <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{mission.desc}</p>
              </div>
              <button className="btn-primary" style={{ padding: '8px 16px', fontSize: '10px', flexShrink: 0 }} onClick={() => speak(mission.name + '. ' + mission.desc)}>🔊</button>
            </div>
          ))}
        </div>
      )}

      {/* Rockets Tab */}
      {activeTab === 'rockets' && (
        <div>
          <div style={{ marginBottom: '28px', padding: '20px', background: 'rgba(0,245,255,0.03)', border: '1px solid rgba(0,245,255,0.15)', borderRadius: '12px' }}>
            <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              Rocket science combines orbital mechanics, thermodynamics, and materials engineering to launch payloads into space. Understanding these fundamental equations is key to designing efficient spacecraft and orbital maneuvers.
            </p>
          </div>
          <div className="grid-2" style={{ gap: '20px' }}>
            {rocketScience.map(r => (
              <div key={r.title} className="glass-card" style={{ padding: '24px' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)', letterSpacing: '1px', marginBottom: '12px' }}>{r.title}</h3>
                <div style={{ background: 'rgba(0,20,60,0.6)', borderRadius: '8px', padding: '14px', marginBottom: '14px', textAlign: 'center' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '18px', color: '#e8d060', letterSpacing: '2px' }}>{r.formula}</span>
                </div>
                <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>{r.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Satellites Tab */}
      {activeTab === 'satellites' && (
        <div>
          <div className="grid-2" style={{ gap: '24px' }}>
            {[
              { title: 'Low Earth Orbit (LEO)', alt: '160–2,000 km', use: 'ISS, Earth observation, Starlink, Hubble', period: '~90 min', speed: '7.8 km/s', desc: 'Most satellites operate here. Close to Earth enabling high-resolution imaging and low latency communications. Main debris zone.' },
              { title: 'Medium Earth Orbit (MEO)', alt: '2,000–35,786 km', use: 'GPS, GLONASS, Galileo navigation', period: '~12 hours', speed: '~3.9 km/s', desc: 'Navigation satellites like GPS orbit here. The Van Allen radiation belts make this a harsh environment.' },
              { title: 'Geostationary Orbit (GEO)', alt: '35,786 km', use: 'Weather, communications, TV broadcast', period: '24 hours', speed: '3.07 km/s', desc: 'Satellites here appear stationary over the same point on Earth. Perfect for weather monitoring and broadcast TV.' },
              { title: 'Sun-Synchronous Orbit (SSO)', alt: '600–800 km', use: 'Earth observation, climate monitoring', period: '~100 min', speed: '~7.5 km/s', desc: 'Polar orbit that passes over any given point at the same local solar time. Enables consistent lighting for imaging.' },
            ].map(s => (
              <div key={s.title} className="glass-card" style={{ padding: '22px' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)', letterSpacing: '1px', marginBottom: '14px' }}>{s.title.toUpperCase()}</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '14px' }}>
                  {[['Altitude', s.alt], ['Orbital Period', s.period], ['Orbital Speed', s.speed]].map(([l, v]) => (
                    <div key={l} style={{ background: 'rgba(0,15,50,0.6)', borderRadius: '6px', padding: '8px' }}>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--text-dim)', letterSpacing: '1px' }}>{l.toUpperCase()}</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: '12px', color: 'var(--accent-cyan)', marginTop: '2px' }}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{ marginBottom: '10px' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--text-dim)', letterSpacing: '1px' }}>USE CASES: </span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--accent-yellow)' }}>{s.use}</span>
                </div>
                <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
