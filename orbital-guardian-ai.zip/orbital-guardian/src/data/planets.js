export const planetsData = [
  {
    id: "mercury", name: "Mercury", radius: 0.38, distance: 6, speed: 0.04, color: "#b5b5b5",
    textureColor: "#8a7a6a", ringColor: null, tilt: 0.034,
    diameter: 4879, gravity: 3.7, temperature: 167, distanceFromSun: 57.9,
    atmosphere: "Minimal (exosphere only)", moons: 0, orbitalPeriod: 88,
    description: "The smallest and innermost planet. Named after the Roman messenger god.",
    facts: ["Smallest planet in solar system","Extreme temperature swings: -180°C to 430°C","No atmosphere to retain heat","One year = 88 Earth days","Surface covered in craters","Second densest planet after Earth"],
    voiceText: "Mercury, the smallest planet, races around the Sun in just 88 days. Despite being closest to the Sun, it is not the hottest planet - that distinction belongs to Venus. With virtually no atmosphere, temperatures swing wildly from negative 180 to 430 degrees Celsius."
  },
  {
    id: "venus", name: "Venus", radius: 0.95, distance: 9, speed: 0.015, color: "#e8cda0",
    textureColor: "#c8941a", ringColor: null, tilt: 177.4,
    diameter: 12104, gravity: 8.87, temperature: 464, distanceFromSun: 108.2,
    atmosphere: "96.5% CO₂, 3.5% N₂", moons: 0, orbitalPeriod: 225,
    description: "Hottest planet with crushing atmosphere. Often called Earth's twin.",
    facts: ["Hottest planet: 464°C average","Rotates backwards","Day longer than its year","Atmospheric pressure 90× Earth","Covered in volcanoes","Brightest object after Moon"],
    voiceText: "Venus is Earth's toxic twin - similar in size, but a hellish world with surface temperatures of 464 degrees Celsius, hot enough to melt lead. Its thick carbon dioxide atmosphere creates a runaway greenhouse effect, and it rotates so slowly that a day on Venus is longer than its year."
  },
  {
    id: "earth", name: "Earth", radius: 1.0, distance: 13, speed: 0.01, color: "#4a9eff",
    textureColor: "#1a6ba0", ringColor: null, tilt: 23.5,
    diameter: 12742, gravity: 9.81, temperature: 15, distanceFromSun: 149.6,
    atmosphere: "78% N₂, 21% O₂", moons: 1, orbitalPeriod: 365,
    description: "Our home world. Only known planet harboring life.",
    facts: ["Only known life-bearing planet","71% of surface is water","Large Moon stabilizes axial tilt","Strong magnetic field","Plate tectonics active","Goldilocks zone location"],
    voiceText: "Earth, our home world, is the only planet known to harbor life. Located in the habitable Goldilocks zone, Earth benefits from liquid water, a protective magnetic field, and an atmosphere that moderates temperatures. Our Moon stabilizes Earth's axial tilt, ensuring stable seasons."
  },
  {
    id: "mars", name: "Mars", radius: 0.53, distance: 17, speed: 0.008, color: "#c1440e",
    textureColor: "#8b2500", ringColor: null, tilt: 25.2,
    diameter: 6779, gravity: 3.71, temperature: -63, distanceFromSun: 227.9,
    atmosphere: "95% CO₂, thin", moons: 2, orbitalPeriod: 687,
    description: "The Red Planet. Prime candidate for human colonization.",
    facts: ["Largest volcano: Olympus Mons (21km)","Deepest canyon: Valles Marineris","Two moons: Phobos and Deimos","Evidence of ancient water","Day length similar to Earth","Target for human colonization"],
    voiceText: "Mars, the Red Planet, is humanity's next frontier. Home to Olympus Mons, the largest volcano in the solar system at 21 kilometers high, and the vast Valles Marineris canyon system. Evidence suggests liquid water once flowed on Mars, making it our best candidate for finding ancient microbial life."
  },
  {
    id: "jupiter", name: "Jupiter", radius: 3.5, distance: 25, speed: 0.005, color: "#c88b3a",
    textureColor: "#b5651d", ringColor: null, tilt: 3.1,
    diameter: 139820, gravity: 24.79, temperature: -110, distanceFromSun: 778.5,
    atmosphere: "89% H₂, 10% He", moons: 95, orbitalPeriod: 4333,
    description: "King of planets. Largest in the solar system by far.",
    facts: ["Largest planet: 1,300 Earths fit inside","Great Red Spot: 350-year storm","95 known moons","Acts as solar system shield","Strongest magnetic field of planets","Day lasts only 9.9 hours"],
    voiceText: "Jupiter, the king of planets, is so massive it contains more than twice the mass of all other planets combined. Its famous Great Red Spot is a storm that has been raging for over 350 years. With 95 known moons and a powerful magnetic field, Jupiter acts as a cosmic shield protecting the inner solar system from asteroids."
  },
  {
    id: "saturn", name: "Saturn", radius: 3.0, distance: 34, speed: 0.003, color: "#e4d191",
    textureColor: "#c4a53a", ringColor: "#d4b896", tilt: 26.7,
    diameter: 116460, gravity: 10.44, temperature: -140, distanceFromSun: 1432,
    atmosphere: "96% H₂, 3% He", moons: 146, orbitalPeriod: 10759,
    description: "The ringed jewel of the solar system.",
    facts: ["Famous ring system (ice and rock)","Least dense planet (floats on water)","146 known moons","Titan has thick atmosphere","Rings span 282,000 km","Hexagonal storm at north pole"],
    voiceText: "Saturn, the ringed jewel of the solar system, is the least dense planet - it could float on water if an ocean large enough existed. Its spectacular ring system spans 282,000 kilometers but is only about 10 meters thick. Saturn has 146 known moons, including Titan which has a thick nitrogen atmosphere and methane lakes."
  },
  {
    id: "uranus", name: "Uranus", radius: 2.0, distance: 42, speed: 0.002, color: "#7de8e8",
    textureColor: "#4fc3c3", ringColor: null, tilt: 97.8,
    diameter: 50724, gravity: 8.87, temperature: -195, distanceFromSun: 2867,
    atmosphere: "83% H₂, 15% He, 2% CH₄", moons: 28, orbitalPeriod: 30589,
    description: "The ice giant that rolls around the Sun on its side.",
    facts: ["Rotates on its side (98° tilt)","Coldest planetary atmosphere: -224°C","Ice giant (water, methane, ammonia)","27 known moons","Discovered by telescope (1781)","Faint ring system"],
    voiceText: "Uranus is the bizarre ice giant that rotates on its side, with an axial tilt of 98 degrees - likely from a massive ancient collision. Its blue-green color comes from methane in the atmosphere absorbing red light. Despite receiving little sunlight, Uranus has the coldest planetary atmosphere in the solar system at negative 224 degrees Celsius."
  },
  {
    id: "neptune", name: "Neptune", radius: 1.9, distance: 50, speed: 0.001, color: "#4b70dd",
    textureColor: "#2850aa", ringColor: null, tilt: 28.3,
    diameter: 49244, gravity: 11.15, temperature: -200, distanceFromSun: 4495,
    atmosphere: "80% H₂, 19% He, 1% CH₄", moons: 16, orbitalPeriod: 59800,
    description: "The windiest planet, the most distant from the Sun.",
    facts: ["Fastest winds: 2,100 km/h","Takes 165 years to orbit Sun","Great Dark Spot (massive storm)","Triton orbits backwards","Predicted before discovered","Farthest from Sun"],
    voiceText: "Neptune, the most distant planet, is a world of extreme weather. Its winds are the fastest in the solar system, reaching 2,100 kilometers per hour. Neptune takes 165 Earth years to complete one orbit, meaning it has completed less than two full trips around the Sun since its discovery in 1846."
  }
];

export const sunData = {
  id: "sun", name: "The Sun", diameter: 1392700, gravity: 274, temperature: 5778,
  description: "The star at the center of our solar system, containing 99.86% of all mass.",
  facts: ["Contains 99.86% of solar system mass","Surface temperature: 5,778 K","Core temperature: 15 million K","Age: 4.6 billion years","Type: Yellow dwarf (G2V)","Will become red giant in ~5 billion years"],
  voiceText: "The Sun, our host star, is an ordinary yet extraordinary star. It contains 99.86% of all the mass in our solar system. Its core reaches 15 million degrees Celsius, where hydrogen fusion generates energy that takes 100,000 years to reach the surface. The Sun has been burning for 4.6 billion years and has enough fuel for another 5 billion."
};
