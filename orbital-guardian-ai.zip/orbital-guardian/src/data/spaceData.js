export const satellitesData = [
  { id: 1, name: "ISS", altitude: 408, velocity: 7.66, inclination: 51.6, type: "station", risk: "medium", owner: "International" },
  { id: 2, name: "Hubble Space Telescope", altitude: 540, velocity: 7.59, inclination: 28.5, type: "observatory", risk: "low", owner: "NASA" },
  { id: 3, name: "Starlink-1001", altitude: 550, velocity: 7.58, inclination: 53, type: "communications", risk: "low", owner: "SpaceX" },
  { id: 4, name: "GOES-16", altitude: 35786, velocity: 3.07, inclination: 0.1, type: "weather", risk: "low", owner: "NOAA" },
  { id: 5, name: "GPS-IIF-12", altitude: 20200, velocity: 3.87, inclination: 55, type: "navigation", risk: "low", owner: "USA" },
  { id: 6, name: "Sentinel-2A", altitude: 786, velocity: 7.46, inclination: 98.6, type: "earth-observation", risk: "medium", owner: "ESA" },
  { id: 7, name: "NOAA-20", altitude: 824, velocity: 7.43, inclination: 98.7, type: "weather", risk: "low", owner: "NOAA" },
  { id: 8, name: "WorldView-3", altitude: 617, velocity: 7.52, inclination: 97.9, type: "commercial", risk: "low", owner: "Maxar" },
];

export const debrisData = [
  { id: 1, name: "Debris Alpha-7", altitude: 412, velocity: 7.65, size: 0.3, threatScore: 87, origin: "Cosmos-2251 collision", risk: "critical" },
  { id: 2, name: "Fragment Beta-3", altitude: 540, velocity: 7.55, size: 0.15, threatScore: 62, origin: "Unknown rocket body", risk: "high" },
  { id: 3, name: "Object Gamma-12", altitude: 780, velocity: 7.44, size: 2.1, threatScore: 45, origin: "Fengyun-1C ASAT test", risk: "medium" },
  { id: 4, name: "Debris Delta-5", altitude: 350, velocity: 7.70, size: 0.08, threatScore: 91, origin: "Iridium-33 collision", risk: "critical" },
  { id: 5, name: "Fragment Epsilon-9", altitude: 620, velocity: 7.50, size: 0.45, threatScore: 34, origin: "SL-16 rocket body", risk: "low" },
  { id: 6, name: "Object Zeta-1", altitude: 850, velocity: 7.41, size: 1.2, threatScore: 73, origin: "ASAT test debris", risk: "high" },
  { id: 7, name: "Debris Eta-22", altitude: 490, velocity: 7.60, size: 0.05, threatScore: 55, origin: "Paint flake", risk: "medium" },
  { id: 8, name: "Fragment Theta-6", altitude: 710, velocity: 7.47, size: 0.9, threatScore: 28, origin: "Decommissioned satellite", risk: "low" },
];

export const collisionPredictions = [
  {
    id: 1, satellite: "ISS", debris: "Debris Alpha-7",
    probability: 12.3, riskLevel: "orange", timeToEncounter: "47h 23m",
    relativeVelocity: 14.2, closestApproach: 0.8,
    insight: "Debris Cluster Alpha has a 12% probability of intersecting the ISS orbit within the next 48 hours. Recommend monitoring."
  },
  {
    id: 2, satellite: "Starlink-1001", debris: "Fragment Beta-3",
    probability: 4.7, riskLevel: "yellow", timeToEncounter: "12h 05m",
    relativeVelocity: 11.8, closestApproach: 2.3,
    insight: "Moderate risk conjunction detected. Beta fragment trajectory suggests a 4.7% chance of catastrophic collision."
  },
  {
    id: 3, satellite: "Hubble Space Telescope", debris: "Debris Delta-5",
    probability: 0.8, riskLevel: "green", timeToEncounter: "6d 14h",
    relativeVelocity: 8.4, closestApproach: 8.7,
    insight: "Low risk event. Delta debris will pass within safe margins. Continue standard monitoring protocol."
  },
  {
    id: 4, satellite: "Sentinel-2A", debris: "Object Zeta-1",
    probability: 31.5, riskLevel: "red", timeToEncounter: "23h 41m",
    relativeVelocity: 16.7, closestApproach: 0.2,
    insight: "CRITICAL: High probability conjunction. Zeta-1 is on near-direct collision course with Sentinel-2A. Immediate maneuver recommended."
  }
];

export const dashboardStats = {
  activeSatellites: 7892,
  trackedDebris: 27852,
  potentialThreats: 147,
  collisionPredictions: 23,
  criticalEvents: 4,
  monitoredCountries: 72
};

export const asteroidData = [
  { name: "Apophis", diameter: 370, velocity: 30.7, missDistance: 31000, hazardous: true, nextApproach: "2029-04-13" },
  { name: "Bennu", diameter: 490, velocity: 28.1, missDistance: 296000, hazardous: true, nextApproach: "2182-09-24" },
  { name: "2020 XR", diameter: 150, velocity: 22.4, missDistance: 800000, hazardous: false, nextApproach: "2025-11-07" },
  { name: "1997 XF11", diameter: 2000, velocity: 35.2, missDistance: 960000, hazardous: false, nextApproach: "2028-10-26" },
  { name: "Eros", diameter: 16840, velocity: 24.5, missDistance: 22400000, hazardous: false, nextApproach: "2031-05-15" },
];

export const spaceWeatherData = [
  { date: "Jan", kpIndex: 2.1, solarFlares: 1, geomagneticActivity: "Quiet" },
  { date: "Feb", kpIndex: 3.5, solarFlares: 3, geomagneticActivity: "Active" },
  { date: "Mar", kpIndex: 5.2, solarFlares: 7, geomagneticActivity: "Minor Storm" },
  { date: "Apr", kpIndex: 4.1, solarFlares: 4, geomagneticActivity: "Active" },
  { date: "May", kpIndex: 6.8, solarFlares: 12, geomagneticActivity: "Moderate Storm" },
  { date: "Jun", kpIndex: 3.2, solarFlares: 2, geomagneticActivity: "Quiet" },
];

export const educationTopics = [
  {
    id: "kessler", title: "Kessler Syndrome", icon: "⚠️",
    description: "A catastrophic cascade of collisions that could render low Earth orbit unusable for generations.",
    content: "Kessler Syndrome, proposed by NASA scientist Donald Kessler in 1978, describes a scenario where the density of objects in low Earth orbit becomes high enough that collisions between objects could cause a cascade — each collision generating debris that increases the likelihood of further collisions. This chain reaction could exponentially increase space debris and make certain orbital regions impassable.",
    facts: ["Proposed by Donald Kessler in 1978", "Critical density threshold estimated ~700km altitude", "Could trap humanity on Earth", "Iridium-Cosmos 2009 collision added 2,000+ fragments", "China ASAT test added 3,500+ trackable pieces"],
    voiceText: "Kessler Syndrome is perhaps the most dangerous threat to our spacefaring future. If orbital debris reaches a critical density, collisions between objects create more debris, triggering more collisions in an unstoppable cascade. This could render low Earth orbit permanently unusable, trapping humanity below and destroying the space infrastructure we depend on for communications, navigation, and weather forecasting."
  },
  {
    id: "blackholes", title: "Black Holes", icon: "🕳️",
    description: "Regions of spacetime where gravity is so strong nothing, not even light, can escape.",
    content: "Black holes are formed when massive stars collapse at the end of their lives. Their gravity is so extreme that the escape velocity exceeds the speed of light. The boundary beyond which nothing can return is called the event horizon. At the center lies the singularity, where density and gravity become theoretically infinite.",
    facts: ["Nearest black hole: 1,000 light-years away", "Supermassive ones exist in galaxy centers", "Time dilates near black holes", "Hawking radiation slowly evaporates them", "First imaged in 2019 (M87*)"],
    voiceText: "Black holes are among the most extreme objects in the universe. Where a star once burned with nuclear fusion, a black hole bends spacetime so severely that even light cannot escape its gravitational grip. At their centers, all known laws of physics break down at the singularity. Yet from a safe distance, black holes power quasars and shape entire galaxies."
  },
  {
    id: "nebulae", title: "Nebulae", icon: "🌌",
    description: "Vast clouds of gas and dust — the stellar nurseries and graveyards of the universe.",
    content: "Nebulae are enormous clouds of gas and dust in space. They come in several types: emission nebulae glow as ionized gas, reflection nebulae scatter starlight, and planetary nebulae are the remnants of dying stars. The most spectacular are stellar nurseries where new stars are born from collapsing clouds of hydrogen.",
    facts: ["Orion Nebula visible to naked eye", "Some span hundreds of light-years", "Birthplace of new solar systems", "Composed mainly of hydrogen and helium", "Eagle Nebula hosts 'Pillars of Creation'"],
    voiceText: "Nebulae are the cosmic cradles and graves of stars. In stellar nurseries like the Orion Nebula, gravity pulls clouds of hydrogen together until nuclear fusion ignites, birthing new stars and planetary systems. Planetary nebulae, despite their name, have nothing to do with planets — they are the glowing shells of gas expelled by dying stars like our Sun will eventually become."
  },
  {
    id: "exoplanets", title: "Exoplanets", icon: "🪐",
    description: "Worlds orbiting distant stars — over 5,500 confirmed and counting.",
    content: "Exoplanets are planets orbiting stars beyond our Sun. Since the first confirmed discovery in 1992, astronomers have found over 5,500 confirmed exoplanets using techniques including transit photometry and radial velocity measurements. Some orbit in the habitable zones of their stars, where liquid water could exist.",
    facts: ["5,500+ confirmed exoplanets", "TRAPPIST-1 system has 3 habitable zone planets", "Some have multiple suns", "Rogue planets drift without stars", "James Webb telescope revolutionizing discovery"],
    voiceText: "Exoplanet science has transformed our understanding of the universe. We now know that planets are not rare cosmic accidents — they are ubiquitous, with every star system likely hosting multiple worlds. The TRAPPIST-1 system, just 40 light-years away, has three Earth-sized planets in the habitable zone, making it one of the most exciting candidates in the search for extraterrestrial life."
  }
];

export const knowledgeBase = {
  mars: "Mars is known as the Red Planet because of iron oxide (rust) on its surface. It has two small moons, Phobos and Deimos, and is home to Olympus Mons, the tallest volcano in the solar system at 21 kilometers high.",
  jupiter: "Jupiter is the largest planet in our solar system, containing over twice the mass of all other planets combined. Its Great Red Spot is a storm that has been raging for over 350 years.",
  debris: "Space debris, or orbital debris, consists of man-made objects in orbit that no longer serve any useful purpose. There are currently over 27,000 pieces of trackable debris and millions of smaller fragments.",
  iss: "The International Space Station orbits at approximately 408 kilometers altitude, completing 16 orbits per day. It has been continuously inhabited since November 2000.",
  blackhole: "A black hole is a region of spacetime where gravity is so strong that nothing, not even light, can escape. They form when massive stars collapse at the end of their lives.",
  satellite: "Satellites are objects placed in orbit around Earth for various purposes including communications, weather monitoring, navigation (GPS), and scientific research. Over 7,800 active satellites currently orbit Earth."
};
