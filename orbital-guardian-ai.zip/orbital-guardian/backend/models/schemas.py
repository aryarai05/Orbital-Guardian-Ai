"""
Orbital Guardian AI — Pydantic Data Models / Schemas
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


class RiskLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class RiskColor(str, Enum):
    green = "green"
    yellow = "yellow"
    orange = "orange"
    red = "red"


# ── Input Schemas ────────────────────────────────────────────────────────────

class CollisionInput(BaseModel):
    satellite_speed: float = Field(..., ge=0.1, le=15.0, description="Satellite speed in km/s")
    satellite_altitude: float = Field(..., ge=150, le=100000, description="Satellite altitude in km")
    debris_velocity: float = Field(..., ge=0.1, le=15.0, description="Debris velocity in km/s")
    debris_altitude: float = Field(..., ge=150, le=100000, description="Debris altitude in km")
    satellite_name: Optional[str] = Field("Unknown Satellite", max_length=100)
    debris_name: Optional[str] = Field("Unknown Debris", max_length=100)
    inclination_deg: Optional[float] = Field(None, ge=0, le=180)
    debris_size_m: Optional[float] = Field(None, ge=0.001, le=100)

    class Config:
        json_schema_extra = {
            "example": {
                "satellite_speed": 7.66,
                "satellite_altitude": 408,
                "debris_velocity": 7.65,
                "debris_altitude": 412,
                "satellite_name": "ISS",
                "debris_name": "Debris Alpha-7"
            }
        }


# ── Output Schemas ────────────────────────────────────────────────────────────

class BoundingBox(BaseModel):
    x: float = Field(..., ge=0, le=1)
    y: float = Field(..., ge=0, le=1)
    width: float = Field(..., ge=0, le=1)
    height: float = Field(..., ge=0, le=1)


class DebrisDetection(BaseModel):
    id: int
    bbox: BoundingBox
    confidence: float
    class_name: str
    size_estimate: str
    threat_level: RiskLevel


class CollisionResult(BaseModel):
    satellite_name: str
    debris_name: str
    collision_probability: float = Field(..., ge=0, le=100, description="Probability in %")
    risk_level: RiskColor
    time_to_encounter: str
    relative_velocity_km_s: float
    closest_approach_km: float
    kinetic_energy_gj: float
    fragments_if_impact: int
    ai_insight: str
    model_confidence: float
    computed_at: datetime


class DebrisDetectionResult(BaseModel):
    filename: str
    file_size_mb: float
    debris_count: int
    threat_score: float
    risk_level: RiskLevel
    model: str
    model_confidence: float
    processing_time_s: float
    orbit_zone: str
    detections: List[Dict[str, Any]]
    ai_insight: str
    analyzed_at: datetime


class SatelliteInfo(BaseModel):
    id: int
    norad: int
    name: str
    altitude: float
    velocity: float
    inclination: float
    type: str
    owner: str
    risk: RiskLevel
    status: str


class ConjunctionEvent(BaseModel):
    id: int
    satellite: str
    debris: str
    probability: float
    risk: RiskColor
    time_to_encounter: str
    relative_velocity_km_s: float
    closest_approach_km: float
    ai_insight: Optional[str] = None


class DashboardStats(BaseModel):
    active_satellites: int
    tracked_debris: int
    potential_threats: int
    collision_predictions: int
    critical_events: int
    monitored_countries: int
    last_updated: datetime
    system_status: str
    kp_index: float
    solar_activity: str


class SpaceWeather(BaseModel):
    kp_index: float
    ap_index: int
    geomagnetic_activity: str
    solar_wind_speed_km_s: float
    solar_flux_f107: float
    proton_flux: float
    electron_flux: float
    aurora_forecast: str
    satellite_drag_factor: float
    updated: datetime


class PlanetInfo(BaseModel):
    name: str
    diameter_km: int
    mass_kg: float
    gravity_m_s2: float
    distance_from_sun_million_km: float
    orbital_period_days: float
    rotation_period_hours: float
    average_temperature_celsius: int
    atmosphere: str
    moons: int
    rings: bool
    description: str
    interesting_facts: List[str]
