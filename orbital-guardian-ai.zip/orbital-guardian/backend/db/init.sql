-- Orbital Guardian AI — Database Schema
-- PostgreSQL 16

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Satellites ───────────────────────────────────────────────
CREATE TABLE satellites (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    norad_id      INTEGER UNIQUE NOT NULL,
    name          VARCHAR(120) NOT NULL,
    cospar_id     VARCHAR(20),
    owner         VARCHAR(80),
    type          VARCHAR(60),
    altitude_km   NUMERIC(10, 2),
    velocity_km_s NUMERIC(8, 4),
    inclination   NUMERIC(7, 4),
    eccentricity  NUMERIC(12, 8),
    period_min    NUMERIC(10, 4),
    launch_date   DATE,
    status        VARCHAR(20) DEFAULT 'active',
    tle_line1     VARCHAR(70),
    tle_line2     VARCHAR(70),
    updated_at    TIMESTAMPTZ DEFAULT NOW(),
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Debris Objects ───────────────────────────────────────────
CREATE TABLE debris_objects (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    catalog_id    VARCHAR(20) UNIQUE NOT NULL,
    name          VARCHAR(120),
    origin        VARCHAR(200),
    altitude_km   NUMERIC(10, 2),
    velocity_km_s NUMERIC(8, 4),
    inclination   NUMERIC(7, 4),
    size_m        NUMERIC(10, 4),
    mass_kg       NUMERIC(12, 4),
    threat_score  NUMERIC(5, 2),
    risk_level    VARCHAR(10) CHECK (risk_level IN ('low','medium','high','critical')),
    tle_line1     VARCHAR(70),
    tle_line2     VARCHAR(70),
    decay_date    DATE,
    updated_at    TIMESTAMPTZ DEFAULT NOW(),
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Conjunction Events ───────────────────────────────────────
CREATE TABLE conjunction_events (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    satellite_id          UUID REFERENCES satellites(id),
    debris_id             UUID REFERENCES debris_objects(id),
    tca                   TIMESTAMPTZ NOT NULL,         -- Time of closest approach
    probability           NUMERIC(6, 4) NOT NULL,      -- 0.0 – 1.0
    risk_level            VARCHAR(10),
    miss_distance_km      NUMERIC(10, 4),
    relative_velocity_km_s NUMERIC(8, 4),
    satellite_pos_x       NUMERIC(14, 6),
    satellite_pos_y       NUMERIC(14, 6),
    satellite_pos_z       NUMERIC(14, 6),
    debris_pos_x          NUMERIC(14, 6),
    debris_pos_y          NUMERIC(14, 6),
    debris_pos_z          NUMERIC(14, 6),
    maneuver_recommended  BOOLEAN DEFAULT FALSE,
    maneuver_dv_m_s       NUMERIC(8, 4),
    ai_insight            TEXT,
    resolved              BOOLEAN DEFAULT FALSE,
    created_at            TIMESTAMPTZ DEFAULT NOW()
);

-- ── Debris Detections (from imagery) ────────────────────────
CREATE TABLE debris_detections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    image_filename  VARCHAR(200),
    model_version   VARCHAR(50) DEFAULT 'YOLOv8m-Space-v2.1',
    debris_count    INTEGER,
    threat_score    NUMERIC(5, 2),
    risk_level      VARCHAR(10),
    confidence      NUMERIC(5, 2),
    processing_ms   INTEGER,
    detections_json JSONB,
    orbit_zone      VARCHAR(10),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Space Weather Events ─────────────────────────────────────
CREATE TABLE space_weather (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    observed_at     TIMESTAMPTZ NOT NULL,
    kp_index        NUMERIC(4, 2),
    ap_index        INTEGER,
    solar_flux_f107 NUMERIC(8, 2),
    solar_wind_speed NUMERIC(8, 2),
    bz_nt           NUMERIC(8, 3),
    activity_level  VARCHAR(30),
    storm_level     VARCHAR(20),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Solar Flare Events ───────────────────────────────────────
CREATE TABLE solar_flares (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    observed_at   TIMESTAMPTZ NOT NULL,
    class         VARCHAR(10) NOT NULL,
    peak_flux     NUMERIC(12, 8),
    duration_min  INTEGER,
    active_region VARCHAR(20),
    impact        TEXT,
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Indexes ──────────────────────────────────────────────────
CREATE INDEX idx_conj_tca           ON conjunction_events(tca);
CREATE INDEX idx_conj_risk          ON conjunction_events(risk_level);
CREATE INDEX idx_conj_probability   ON conjunction_events(probability DESC);
CREATE INDEX idx_debris_risk        ON debris_objects(risk_level);
CREATE INDEX idx_debris_alt         ON debris_objects(altitude_km);
CREATE INDEX idx_sat_status         ON satellites(status);
CREATE INDEX idx_weather_observed   ON space_weather(observed_at DESC);

-- ── Seed: Sample Data ────────────────────────────────────────
INSERT INTO satellites (norad_id, name, owner, type, altitude_km, velocity_km_s, inclination) VALUES
    (25544, 'ISS',                   'International', 'station',      408.0, 7.66, 51.6),
    (20580, 'Hubble Space Telescope','NASA',          'observatory',  540.0, 7.59, 28.5),
    (44713, 'Starlink-1001',         'SpaceX',        'comms',        550.0, 7.58, 53.0),
    (41866, 'GOES-16',               'NOAA',          'weather',    35786.0, 3.07,  0.1),
    (40697, 'Sentinel-2A',           'ESA',           'earth-obs',    786.0, 7.46, 98.6);

INSERT INTO debris_objects (catalog_id, name, origin, altitude_km, velocity_km_s, size_m, threat_score, risk_level) VALUES
    ('DEB-A7',  'Debris Alpha-7',   'Cosmos-2251 collision 2009',    412.0, 7.65, 0.30, 87.0, 'critical'),
    ('DEB-B3',  'Fragment Beta-3',  'Unknown rocket body',           540.0, 7.55, 0.15, 62.0, 'high'),
    ('DEB-G12', 'Object Gamma-12',  'Fengyun-1C ASAT test 2007',    780.0, 7.44, 2.10, 45.0, 'medium'),
    ('DEB-D5',  'Debris Delta-5',   'Iridium-33 collision 2009',    350.0, 7.70, 0.08, 91.0, 'critical'),
    ('DEB-Z1',  'Object Zeta-1',    'ASAT test debris',              850.0, 7.41, 1.20, 73.0, 'high');
