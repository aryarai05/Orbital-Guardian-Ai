"""
Orbital Guardian AI — Orbital Mechanics Utilities
Core calculations for satellite orbit analysis and conjunction prediction.
"""

import math
import numpy as np
from typing import Tuple, List, Optional


# ── Constants ────────────────────────────────────────────────────────────────
MU_EARTH = 3.986004418e14   # Earth gravitational parameter (m^3/s^2)
EARTH_RADIUS_KM = 6371.0    # Mean Earth radius (km)
J2 = 1.08263e-3             # Earth oblateness J2 coefficient
AU_KM = 1.496e8             # 1 AU in km


# ── Basic Orbital Parameters ─────────────────────────────────────────────────

def orbital_velocity(altitude_km: float) -> float:
    """
    Circular orbital velocity at given altitude.
    Returns velocity in km/s.
    """
    r = (EARTH_RADIUS_KM + altitude_km) * 1000  # Convert to meters
    v = math.sqrt(MU_EARTH / r)
    return v / 1000  # Return in km/s


def orbital_period(altitude_km: float) -> float:
    """
    Orbital period for circular orbit at given altitude.
    Returns period in minutes.
    """
    r = (EARTH_RADIUS_KM + altitude_km) * 1000
    T = 2 * math.pi * math.sqrt(r**3 / MU_EARTH)
    return T / 60  # Return in minutes


def escape_velocity(altitude_km: float = 0) -> float:
    """
    Escape velocity from Earth at given altitude.
    Returns velocity in km/s.
    """
    r = (EARTH_RADIUS_KM + altitude_km) * 1000
    v_esc = math.sqrt(2 * MU_EARTH / r)
    return v_esc / 1000


def hohmann_delta_v(r1_km: float, r2_km: float) -> Tuple[float, float]:
    """
    Hohmann transfer delta-v between two circular orbits.
    r1, r2: orbital radii from Earth center in km.
    Returns (dv1, dv2) in km/s.
    """
    r1 = r1_km * 1000
    r2 = r2_km * 1000
    
    v1 = math.sqrt(MU_EARTH / r1)
    v2 = math.sqrt(MU_EARTH / r2)
    
    # Transfer orbit semi-major axis
    a_t = (r1 + r2) / 2
    
    # Velocities at transfer orbit apsis
    v_t1 = math.sqrt(MU_EARTH * (2/r1 - 1/a_t))
    v_t2 = math.sqrt(MU_EARTH * (2/r2 - 1/a_t))
    
    dv1 = abs(v_t1 - v1) / 1000  # km/s
    dv2 = abs(v2 - v_t2) / 1000  # km/s
    
    return dv1, dv2


# ── Conjunction Geometry ─────────────────────────────────────────────────────

def relative_velocity(
    sat_vel: float, deb_vel: float,
    sat_alt: float, deb_alt: float,
    inclination_diff_deg: float = 0.0
) -> float:
    """
    Estimate relative velocity at closest approach.
    Returns relative velocity in km/s.
    """
    alt_diff = abs(sat_alt - deb_alt)
    
    # Radial component from altitude difference
    v_radial = alt_diff * 0.001
    
    # Along-track component
    v_along = sat_vel - deb_vel
    
    # Cross-track component from inclination difference
    v_cross = (sat_vel + deb_vel) / 2 * math.sin(math.radians(inclination_diff_deg / 2))
    
    rel_v = math.sqrt(v_radial**2 + v_along**2 + v_cross**2)
    return round(rel_v, 4)


def collision_cross_section(sat_size_m: float, deb_size_m: float) -> float:
    """
    Compute combined collision cross-section area in m^2.
    Uses hard-body sphere approximation.
    """
    r_combined = (sat_size_m + deb_size_m) / 2
    return math.pi * r_combined**2


def kinetic_energy_gj(
    mass_kg: float,
    relative_velocity_km_s: float
) -> float:
    """
    Kinetic energy of collision in gigajoules.
    """
    v_ms = relative_velocity_km_s * 1000
    ke = 0.5 * mass_kg * v_ms**2
    return ke / 1e9  # Convert to GJ


def debris_fragment_estimate(mass_kg: float, relative_velocity_km_s: float) -> int:
    """
    Estimate number of trackable fragments from hypervelocity impact.
    Based on NASA breakup model simplified formula.
    """
    ke = kinetic_energy_gj(mass_kg, relative_velocity_km_s)
    # Simplified: more energy = more fragments
    fragments = int(500 * ke**0.7 + np.random.normal(0, 500))
    return max(100, fragments)


# ── Atmospheric Drag ──────────────────────────────────────────────────────────

def atmospheric_density(altitude_km: float) -> float:
    """
    Simplified exponential atmospheric density model.
    Returns density in kg/m^3.
    """
    rho0 = 1.225      # Sea level density (kg/m^3)
    H = 8.5           # Scale height (km) — simplified single exponential

    # Use different scale heights for different altitude bands
    if altitude_km < 100:
        H = 8.0
        rho0 = 1.225 * math.exp(-altitude_km / H)
    elif altitude_km < 300:
        H = 40.0
        rho0_300 = 1.225 * math.exp(-100 / 8.0)
        rho0 = rho0_300 * math.exp(-(altitude_km - 100) / H)
    elif altitude_km < 600:
        H = 70.0
        rho0_600 = 1e-7
        rho0 = rho0_600 * math.exp(-(altitude_km - 300) / H)
    else:
        H = 150.0
        rho0_ref = 1e-10
        rho0 = rho0_ref * math.exp(-(altitude_km - 600) / H)

    return max(rho0, 1e-15)


def orbital_decay_rate(
    altitude_km: float,
    cd: float = 2.2,
    area_m2: float = 10.0,
    mass_kg: float = 500.0,
    ballistic_coef: Optional[float] = None
) -> float:
    """
    Estimate altitude decay rate in km/day from atmospheric drag.
    """
    if ballistic_coef is None:
        ballistic_coef = mass_kg / (cd * area_m2)

    rho = atmospheric_density(altitude_km)
    v = orbital_velocity(altitude_km) * 1000  # m/s
    r = (EARTH_RADIUS_KM + altitude_km) * 1000  # m

    drag_accel = 0.5 * rho * v**2 * (1 / ballistic_coef)
    dadt = -2 * drag_accel * r / v  # m/s in altitude

    return abs(dadt) * 86400 / 1000  # km/day


def days_to_reentry(altitude_km: float, mass_kg: float = 500, area_m2: float = 10) -> float:
    """
    Rough estimate of days until object re-enters atmosphere (below 80 km).
    """
    alt = altitude_km
    days = 0
    step = 1  # 1 day steps

    while alt > 80 and days < 100000:
        decay = orbital_decay_rate(alt, mass_kg=mass_kg, area_m2=area_m2)
        alt -= decay * step
        days += step

    return days


# ── TLE Parsing ───────────────────────────────────────────────────────────────

def parse_tle(line1: str, line2: str) -> dict:
    """
    Parse Two-Line Element set into orbital parameters.
    """
    try:
        catalog_number = int(line1[2:7])
        epoch_year = int(line1[18:20])
        epoch_day = float(line1[20:32])
        bstar = float(line1[53:61].replace(' ', ''))

        inclination = float(line2[8:16])
        raan = float(line2[17:25])
        eccentricity = float('0.' + line2[26:33])
        arg_perigee = float(line2[34:42])
        mean_anomaly = float(line2[43:51])
        mean_motion = float(line2[52:63])

        # Compute semi-major axis from mean motion
        n = mean_motion * 2 * math.pi / 86400  # rad/s
        a = (MU_EARTH / n**2) ** (1/3) / 1000  # km
        perigee = a * (1 - eccentricity) - EARTH_RADIUS_KM
        apogee = a * (1 + eccentricity) - EARTH_RADIUS_KM

        return {
            "catalog_number": catalog_number,
            "epoch_year": epoch_year,
            "epoch_day": epoch_day,
            "bstar": bstar,
            "inclination_deg": inclination,
            "raan_deg": raan,
            "eccentricity": eccentricity,
            "arg_perigee_deg": arg_perigee,
            "mean_anomaly_deg": mean_anomaly,
            "mean_motion_rev_per_day": mean_motion,
            "semi_major_axis_km": round(a, 2),
            "perigee_km": round(perigee, 2),
            "apogee_km": round(apogee, 2),
            "orbital_period_min": round(1440 / mean_motion, 2),
        }
    except Exception as e:
        return {"error": str(e)}


# ── Quick Test ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=== Orbital Mechanics Utilities — Quick Test ===\n")

    # ISS orbit
    alt = 408
    print(f"ISS at {alt} km altitude:")
    print(f"  Orbital velocity:  {orbital_velocity(alt):.3f} km/s")
    print(f"  Orbital period:    {orbital_period(alt):.1f} min")
    print(f"  Escape velocity:   {escape_velocity(alt):.3f} km/s")
    print(f"  Decay rate:        {orbital_decay_rate(alt):.4f} km/day")
    print(f"  Days to reentry:   {days_to_reentry(alt):,.0f} days\n")

    # Hohmann transfer LEO -> GEO
    r1 = EARTH_RADIUS_KM + 400   # LEO
    r2 = EARTH_RADIUS_KM + 35786 # GEO
    dv1, dv2 = hohmann_delta_v(r1, r2)
    print(f"Hohmann transfer LEO→GEO:")
    print(f"  Δv1: {dv1:.3f} km/s  |  Δv2: {dv2:.3f} km/s  |  Total: {dv1+dv2:.3f} km/s\n")

    # Collision energy
    ke = kinetic_energy_gj(500, 14.2)
    frags = debris_fragment_estimate(500, 14.2)
    print(f"Hypervelocity impact (500 kg @ 14.2 km/s):")
    print(f"  Kinetic energy:   {ke:.1f} GJ")
    print(f"  Fragment estimate: ~{frags:,}")
