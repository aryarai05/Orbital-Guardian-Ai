"""
Orbital Guardian AI — Satellites Router
Handles satellite catalog, TLE data, and orbital parameter queries.
"""

from fastapi import APIRouter, Query, HTTPException
from typing import Optional, List
import math

router = APIRouter(prefix="/satellites", tags=["Satellites"])

SATELLITE_DB = [
    {"id": 1,  "norad": 25544, "name": "ISS",                    "altitude": 408,   "velocity": 7.66, "inclination": 51.6, "type": "station",      "owner": "International", "risk": "medium", "status": "active"},
    {"id": 2,  "norad": 20580, "name": "Hubble Space Telescope",  "altitude": 540,   "velocity": 7.59, "inclination": 28.5, "type": "observatory",   "owner": "NASA",          "risk": "low",    "status": "active"},
    {"id": 3,  "norad": 44713, "name": "Starlink-1001",           "altitude": 550,   "velocity": 7.58, "inclination": 53.0, "type": "comms",         "owner": "SpaceX",        "risk": "low",    "status": "active"},
    {"id": 4,  "norad": 41866, "name": "GOES-16",                 "altitude": 35786, "velocity": 3.07, "inclination": 0.1,  "type": "weather",       "owner": "NOAA",          "risk": "low",    "status": "active"},
    {"id": 5,  "norad": 26871, "name": "GPS-IIF-12",              "altitude": 20200, "velocity": 3.87, "inclination": 55.0, "type": "navigation",    "owner": "USAF",          "risk": "low",    "status": "active"},
    {"id": 6,  "norad": 40697, "name": "Sentinel-2A",             "altitude": 786,   "velocity": 7.46, "inclination": 98.6, "type": "earth-obs",     "owner": "ESA",           "risk": "medium", "status": "active"},
    {"id": 7,  "norad": 43013, "name": "NOAA-20",                 "altitude": 824,   "velocity": 7.43, "inclination": 98.7, "type": "weather",       "owner": "NOAA",          "risk": "low",    "status": "active"},
    {"id": 8,  "norad": 40115, "name": "WorldView-3",             "altitude": 617,   "velocity": 7.52, "inclination": 97.9, "type": "commercial",    "owner": "Maxar",         "risk": "low",    "status": "active"},
    {"id": 9,  "norad": 49260, "name": "James Webb Space Telescope","altitude": 1500000,"velocity": 0.2,"inclination": 0.0, "type": "observatory",   "owner": "NASA/ESA/CSA",  "risk": "low",    "status": "active"},
    {"id": 10, "norad": 48274, "name": "Landsat-9",               "altitude": 705,   "velocity": 7.48, "inclination": 98.2, "type": "earth-obs",     "owner": "USGS/NASA",     "risk": "low",    "status": "active"},
]


@router.get("/")
async def list_satellites(
    type: Optional[str] = Query(None, description="Filter by type"),
    risk: Optional[str] = Query(None, description="Filter by risk level"),
    owner: Optional[str] = Query(None, description="Filter by owner"),
    limit: int = Query(50, ge=1, le=1000)
):
    """List all tracked active satellites with optional filters."""
    results = SATELLITE_DB
    if type:
        results = [s for s in results if s["type"] == type]
    if risk:
        results = [s for s in results if s["risk"] == risk]
    if owner:
        results = [s for s in results if owner.lower() in s["owner"].lower()]
    return {
        "satellites": results[:limit],
        "total": len(results),
        "filters_applied": {"type": type, "risk": risk, "owner": owner}
    }


@router.get("/{satellite_id}")
async def get_satellite(satellite_id: int):
    """Get detailed information for a specific satellite."""
    sat = next((s for s in SATELLITE_DB if s["id"] == satellite_id), None)
    if not sat:
        raise HTTPException(status_code=404, detail=f"Satellite {satellite_id} not found")

    r_km = 6371.0 + sat["altitude"]
    period_min = 2 * math.pi * math.sqrt((r_km * 1000)**3 / 3.986e14) / 60
    orbits_per_day = 1440 / period_min if period_min > 0 else 0

    return {
        **sat,
        "orbital_period_min": round(period_min, 2),
        "orbits_per_day": round(orbits_per_day, 2),
        "ground_track_speed_km_s": round(sat["velocity"] * math.cos(math.radians(sat["inclination"])), 3),
    }


@router.get("/stats/summary")
async def satellite_stats():
    """Summary statistics for the satellite catalog."""
    by_type = {}
    by_owner = {}
    by_risk = {}
    for s in SATELLITE_DB:
        by_type[s["type"]] = by_type.get(s["type"], 0) + 1
        by_owner[s["owner"]] = by_owner.get(s["owner"], 0) + 1
        by_risk[s["risk"]] = by_risk.get(s["risk"], 0) + 1
    return {
        "total": len(SATELLITE_DB),
        "by_type": by_type,
        "by_owner": by_owner,
        "by_risk": by_risk,
        "altitude_ranges": {
            "LEO (200-2000 km)":   sum(1 for s in SATELLITE_DB if 200 <= s["altitude"] <= 2000),
            "MEO (2000-35786 km)": sum(1 for s in SATELLITE_DB if 2000 < s["altitude"] < 35786),
            "GEO (35786 km)":      sum(1 for s in SATELLITE_DB if s["altitude"] == 35786),
            "Beyond GEO":          sum(1 for s in SATELLITE_DB if s["altitude"] > 35786),
        }
    }
